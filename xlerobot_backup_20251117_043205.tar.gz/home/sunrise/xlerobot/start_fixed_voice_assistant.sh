#!/bin/bash
# XLeBot 修复版语音助手启动脚本
# 修复环境变量加载和服务启动顺序问题

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_info "🚀 XLeBot修复版语音助手启动中..."

# 检查项目目录
if [[ ! -f ".env" ]]; then
    log_error ".env文件不存在，请创建配置文件"
    exit 1
fi

# 加载环境变量（强制加载.env）
log_info "🔑 加载环境变量..."
source .env
if [[ $? -ne 0 ]]; then
    log_error "环境变量加载失败"
    exit 1
fi

# 验证关键环境变量
log_info "🔍 验证API密钥..."
if [[ -z "$ALIBABA_CLOUD_ACCESS_KEY_ID" ]]; then
    log_error "ALIBABA_CLOUD_ACCESS_KEY_ID未设置"
    exit 1
fi
if [[ -z "$ALIBABA_CLOUD_ACCESS_KEY_SECRET" ]]; then
    log_error "ALIBABA_CLOUD_ACCESS_KEY_SECRET未设置"
    exit 1
fi
if [[ -z "$QWEN_API_KEY" ]]; then
    log_error "QWEN_API_KEY未设置"
    exit 1
fi

log_success "✅ 环境变量验证通过"

# 加载XLeRobot环境
log_info "🛠️ 加载XLeRobot环境..."
source ./xlerobot_env.sh

# 设置ROS2环境
log_info "🤖 设置ROS2环境..."
source /opt/ros/humble/setup.bash
export PYTHONPATH="/home/sunrise/xlerobot/src:$PYTHONPATH"
export ROS_DOMAIN_ID=42

# 设置Python解释器
export PYTHON_EXECUTABLE="/usr/bin/python3.10"

log_info "🎯 开始启动服务..."

# 创建日志目录
mkdir -p logs

# 函数：启动服务
start_service() {
    local name=$1
    local command=$2
    local log_file="logs/${name}.log"

    log_info "启动 $name 服务..."
    nohup bash -c "$command" > "$log_file" 2>&1 &
    local pid=$!
    echo $pid > "logs/${name}.pid"

    # 等待服务启动
    sleep 2

    if ps -p $pid > /dev/null; then
        log_success "$name 服务启动成功 (PID: $pid)"
        return 0
    else
        log_error "$name 服务启动失败"
        return 1
    fi
}

# 函数：停止所有服务
stop_all_services() {
    log_info "🛑 停止所有服务..."
    for pid_file in logs/*.pid; do
        if [[ -f "$pid_file" ]]; then
            local pid=$(cat "$pid_file")
            if ps -p $pid > /dev/null; then
                kill $pid
                log_info "停止进程 $pid"
            fi
            rm -f "$pid_file"
        fi
    done
}

# 停止现有服务
stop_all_services

# 按正确顺序启动服务

# 1. 首先验证核心组件
log_info "🧪 验证核心组件..."
$PYTHON_EXECUTABLE -c "
import sys
sys.path.insert(0, '/home/sunrise/xlerobot/src')
from modules.asr.websocket.websocket_asr_service import AliyunASRWebSocketService
from modules.llm import LLMOrchestrator
print('✅ 核心模块导入成功')
"

if [[ $? -eq 0 ]]; then
    log_success "✅ 核心组件验证通过"
else
    log_error "❌ 核心组件验证失败"
    exit 1
fi

# 2. 启动ROS2 Master（如果需要）
log_info "🤖 启动ROS2 Master..."
ros2 daemon start &
sleep 1

# 3. 启动ASR系统
start_service "asr" "
    source .env
    source ./xlerobot_env.sh
    source /opt/ros/humble/setup.bash
    export PYTHONPATH='/home/sunrise/xlerobot/src:$PYTHONPATH'
    export ROS_DOMAIN_ID=42
    $PYTHON_EXECUTABLE -c '
import asyncio
from modules.asr.asr_system import ASRSystem

async def run_asr():
    asr = ASRSystem()
    if asr.initialize():
        print(\"✅ ASR系统初始化成功，开始监听...\")
        await asr.start()
    else:
        print(\"❌ ASR系统初始化失败\")
        return

try:
    asyncio.run(run_asr())
except KeyboardInterrupt:
    print(\"\\n🛑 ASR系统停止\")
except Exception as e:
    print(f\"❌ ASR系统异常: {e}\")
'
"

# 4. 启动LLM服务
start_service "llm" "
    source .env
    source ./xlerobot_env.sh
    source /opt/ros/humble/setup.bash
    export PYTHONPATH='/home/sunrise/xlerobot/src:$PYTHONPATH'
    export ROS_DOMAIN_ID=42
    $PYTHON_EXECUTABLE -c '
import asyncio
from modules.llm import LLMOrchestrator

async def run_llm():
    llm = LLMOrchestrator()
    await llm.initialize()
    print(\"✅ LLM系统启动成功，等待请求...\")

    # 保持运行
    while True:
        await asyncio.sleep(1)

try:
    asyncio.run(run_llm())
except KeyboardInterrupt:
    print(\"\\n🛑 LLM系统停止\")
except Exception as e:
    print(f\"❌ LLM系统异常: {e}\")
'
"

# 5. 启动语音助手协调器
start_service "coordinator" "
    source .env
    source ./xlerobot_env.sh
    source /opt/ros/humble/setup.bash
    export PYTHONPATH='/home/sunrise/xlerobot/src:$PYTHONPATH'
    export ROS_DOMAIN_ID=42
    $PYTHON_EXECUTABLE src/xlerobot/nodes/voice_assistant_coordinator.py
"

# 等待所有服务稳定
log_info "⏳ 等待服务稳定..."
sleep 3

# 检查服务状态
log_info "📊 检查服务状态..."
for name in asr llm coordinator; do
    if [[ -f "logs/${name}.pid" ]]; then
        local pid=$(cat "logs/${name}.pid")
        if ps -p $pid > /dev/null; then
            log_success "✅ $name 服务运行中 (PID: $pid)"
        else
            log_warning "⚠️ $name 服务未运行"
        fi
    else
        log_warning "⚠️ $name 服务PID文件不存在"
    fi
done

# 显示系统信息
log_info "📋 系统信息:"
echo "  - Python: $($PYTHON_EXECUTABLE --version)"
echo "  - ROS2: $(ros2 --version | head -1)"
echo "  - 工作目录: $(pwd)"
echo "  - 日志目录: $(pwd)/logs"
echo "  - API密钥: 已配置"

log_success "🎉 XLeBot修复版语音助手启动完成！"
echo ""
echo "📝 使用说明:"
echo "  - 查看日志: tail -f logs/{asr,llm,coordinator}.log"
echo "  - 停止服务: $0 stop"
echo "  - 重新启动: $0 restart"
echo ""
echo "🎤 ASR系统现在正在监听您的语音输入..."
echo "   唤醒词: '傻强'"
echo ""

# 优雅退出时停止服务
trap 'stop_all_services; log_info "🛑 所有服务已停止"; exit 0' INT TERM

# 保持脚本运行
while true; do
    sleep 10

    # 检查关键服务是否还在运行
    all_running=true
    for name in asr llm coordinator; do
        if [[ -f "logs/${name}.pid" ]]; then
            local pid=$(cat "logs/${name}.pid")
            if ! ps -p $pid > /dev/null; then
                log_warning "⚠️ $name 服务已停止"
                all_running=false
            fi
        else
            all_running=false
        fi
    done

    if [[ "$all_running" != "true" ]]; then
        log_error "❌ 关键服务异常，停止所有服务"
        stop_all_services
        exit 1
    fi
done