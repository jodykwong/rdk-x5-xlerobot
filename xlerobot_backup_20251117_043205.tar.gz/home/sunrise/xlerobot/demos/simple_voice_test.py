#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
简单的语音测试脚本 - 严格测试"说傻强得到回应"
"""

import os
import sys
import time
import logging

# 设置环境变量
os.environ["ALIBABA_CLOUD_ACCESS_KEY_ID"] = "LTAI5tQ4E2YNzZkGn9g1JqeY"
os.environ["ALIBABA_CLOUD_ACCESS_KEY_SECRET"] = "Hr1xZdcdz3D9OgFnH1nvWz5rldXVeI"
os.environ["ALIYUN_NLS_APPKEY"] = "4G5BCMccTCW8nC8w"

# 添加项目路径
sys.path.insert(0, "/home/sunrise/xlerobot/src")

# 配置日志
logging.basicConfig(level=logging.WARNING)

def test_basic_imports():
    """测试基本模块导入"""
    print("🔧 测试模块导入...")

    try:
        from modules.asr.asr_system import ASRSystem
        print("✅ ASRSystem导入成功")

        from modules.tts.engine.aliyun_tts_client import AliyunTTSClient
        print("✅ TTS客户端导入成功")

        from modules.llm.qwen_multimodal_llm import QwenMultimodalLLM
        print("✅ LLM客户端导入成功")

        return True

    except Exception as e:
        print(f"❌ 模块导入失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_asr_system():
    """测试ASR系统"""
    print("\n🔧 测试ASR系统...")

    try:
        from modules.asr.asr_system import ASRSystem
        asr_system = ASRSystem()

        # 初始化
        if asr_system.initialize():
            print("✅ ASR系统初始化成功")

            # 检查状态
            status = asr_system.get_status()
            print(f"📊 ASR状态: {status}")

            # 测试TTS
            test_text = "测试语音合成功能"
            print(f"🔊 测试TTS: {test_text}")

            # 尝试播放测试消息
            asr_system.play_response(test_text)
            time.sleep(3)
            print("✅ TTS测试完成")

            return True
        else:
            print("❌ ASR系统初始化失败")
            return False

    except Exception as e:
        print(f"❌ ASR系统测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_microphone():
    """测试麦克风"""
    print("\n🎤 测试麦克风...")

    try:
        import speech_recognition as sr
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()

        print("✅ 麦克风对象创建成功")

        with microphone as source:
            print("🔧 调整麦克风噪音...")
            recognizer.adjust_for_ambient_noise(source, duration=1)

        print("✅ 麦克风测试成功")
        return True

    except Exception as e:
        print(f"❌ 麦克风测试失败: {e}")
        return False

def test_flac():
    """测试FLAC转换"""
    print("\n🎵 测试FLAC转换...")

    try:
        import subprocess
        result = subprocess.run(["flac", "--version"],
                              capture_output=True, text=True)
        if result.returncode == 0:
            version_line = result.stdout.strip()
            print(f"✅ FLAC可用: {version_line}")
            return True
        else:
            print("❌ FLAC不可用")
            return False
    except Exception as e:
        print(f"❌ FLAC测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("🎯 XleRobot Epic1 简单语音测试")
    print("=" * 50)

    tests = [
        ("模块导入", test_basic_imports),
        ("FLAC转换", test_flac),
        ("麦克风", test_microphone),
        ("ASR系统", test_asr_system)
    ]

    passed = 0
    total = len(tests)

    for test_name, test_func in tests:
        print(f"\n📋 {test_name}测试...")
        if test_func():
            passed += 1
        else:
            print(f"❌ {test_name}测试失败")

    print(f"\n📊 测试结果: {passed}/{total} 通过")

    if passed == total:
        print("🎉 所有测试通过！系统应该可以正常工作")
        print("🗣️ 请现在清晰地说出'傻强'来测试完整功能")
    else:
        print("⚠️ 部分测试失败，需要进一步排查")

if __name__ == "__main__":
    main()