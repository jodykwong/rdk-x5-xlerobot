#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
XleRobot Epic1 快速语音演示
简化的实时语音交互测试，用于快速验证功能
"""

import os
import sys
import asyncio
import logging
import time
from pathlib import Path

# 设置环境变量
os.environ["ALIBABA_CLOUD_ACCESS_KEY_ID"] = "LTAI5tQ4E2YNzZkGn9g1JqeY"
os.environ["ALIBABA_CLOUD_ACCESS_KEY_SECRET"] = "Hr1xZdcdz3D9OgFnH1nvWz5rldXVeI"
os.environ["ALIYUN_NLS_APPKEY"] = "4G5BCMccTCW8nC8w"

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

from modules.asr.asr_system import ASRSystem

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def quick_voice_demo():
    """快速语音演示"""
    print("🎙️  Epic1快速语音演示")
    print("=" * 50)
    print("测试步骤：")
    print("1. 初始化系统")
    print("2. 播放欢迎语音")
    print("3. 启动5秒监听测试")
    print("4. 演示命令处理")
    print("=" * 50)

    try:
        # 1. 初始化系统
        print("\n🚀 步骤1: 初始化ASR系统...")
        asr = ASRSystem()

        if not asr.initialize():
            print("❌ 初始化失败")
            return False

        status = asr.get_status()
        print(f"✅ 系统状态: {status['state']}")
        print(f"🎤 麦克风: {'可用' if status['microphone_available'] else '不可用'}")

        # 2. 播放欢迎语音
        print("\n🔊 步骤2: 播放欢迎语音...")
        asr.play_response("你好，我是傻强，Epic1语音助手已准备就绪")
        await asyncio.sleep(3)

        # 3. 演示命令处理
        print("\n🤖 步骤3: 演示命令处理...")
        test_commands = [
            ("今日天气点样", "天气查询"),
            ("现在几时", "时间查询"),
            ("播放音乐", "娱乐控制"),
            ("开灯", "家居控制")
        ]

        for command, description in test_commands:
            print(f"\n  📝 处理命令: {description}")
            print(f"  🎤 用户输入: {command}")

            response = await asr._process_command(command)
            print(f"  🤖 系统回复: {response}")

            if response:
                print(f"  🔊 播放回复...")
                asr.play_response(response)
                await asyncio.sleep(2)

        # 4. 播放结束语音
        print("\n🏁 步骤4: 播放结束语音...")
        asr.play_response("演示完成，系统正常工作")
        await asyncio.sleep(2)

        print("\n✅ 快速演示完成！")
        print("💡 系统功能正常，可以进行完整语音交互测试")

        return True

    except Exception as e:
        print(f"❌ 演示失败: {e}")
        return False

if __name__ == "__main__":
    asyncio.run(quick_voice_demo())