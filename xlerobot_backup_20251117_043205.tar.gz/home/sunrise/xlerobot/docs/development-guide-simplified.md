# XleRobot 简化开发指导

**版本**: v2.0 (简化架构版)
**更新日期**: 2025-11-08
**适用**: 迭代1 - 纯在线服务开发
**目标开发者**: 遵循简化原则的开发团队

---

## 🎯 开发核心原则

### 1. 简单优先原则
- **目标代码量**: Story 1.1 <150行, Story 1.2 <200行
- **避免过度工程化**: 不实现不必要的复杂功能
- **API优先**: 优先使用阿里云API而非本地处理
- **快速验证**: 专注快速验证用户需求

### 2. 硬件约束原则
- **内存限制**: 总内存使用 <4GB (运行时)
- **CPU限制**: 空闲时CPU使用率 <50%
- **实时性**: 语音交互延迟 <500ms
- **架构**: ARM Cortex-A55优化

### 3. 技术栈约束
- **Python版本**: 强制Python 3.10
- **ROS2版本**: 强制ROS2 Humble
- **依赖管理**: 最小化第三方依赖
- **代码风格**: 遵循简化设计模式

---

## 🏗️ 迭代1开发架构

### 项目结构 (简化版)
```
xlerobot/
├── src/
│   └── xlerobot_phase1/           # 总计~700行
│       ├── __init__.py           # ~20行
│       ├── audio_capture_node.py # ~80行 - Story 1.1
│       ├── audio_processor.py    # ~50行 - Story 1.1
│       ├── wake_word_detector.py # ~100行 - Story 1.2
│       ├── wake_word_config.py   # ~40行 - Story 1.2
│       ├── wake_word_node.py     # ~60行 - Story 1.2
│       ├── voice_recognition.py  # ~200行 - Story 1.3
│       ├── voice_synthesis.py    # ~150行 - Story 1.4
│       └── utils/                # 公共工具
│           └── aliyun_client.py  # ~50行
├── docs/
│   ├── stories/                  # Story文档
│   └── architecture-decisions-*.md
└── setup_xlerobot_env.sh         # 环境配置
```

### 依赖管理 (最小化)
```python
# 核心依赖 (requirements-sprint1.txt)
alibabacloud-tea-openapi==0.3.7    # 阿里云API
requests>=2.31.0                   # HTTP客户端
rclpy                              # ROS2 Python客户端
pyaudio                            # 基础音频采集
numpy                              # 数组处理
```

---

## 📋 Story开发指导

### Story 1.1: 音频采集系统 (~150行)

**开发重点**:
- 使用 `pyaudio` 进行基础音频采集
- 支持16kHz采样率，16位PCM格式
- 基础音频质量检查 (静音检测、音量检测)
- ROS2节点封装

**关键实现**:
```python
# audio_capture_node.py (~80行)
import pyaudio
import numpy as np
import rclpy
from rclpy.node import Node

class AudioCaptureNode(Node):
    def __init__(self):
        super().__init__('audio_capture')
        # 简单的音频采集配置
        self.format = pyaudio.paInt16
        self.channels = 1
        self.rate = 16000
        self.chunk = 1024

    def capture_audio(self):
        # 基础音频采集逻辑
        pass

    def check_audio_quality(self, audio_data):
        # 简单质量检查
        pass
```

**避免的过度工程化**:
- ❌ 复杂的音频增强算法
- ❌ 多格式音频转换器
- ❌ 详细的音频分析功能
- ❌ 高级错误处理和恢复

### Story 1.2: 基础语音唤醒 (~200行)

**开发重点**:
- 集成阿里云唤醒词API
- "傻强"唤醒词检测
- 简单的唤醒/休眠状态管理
- 唤醒成功指示

**关键实现**:
```python
# wake_word_detector.py (~100行)
import requests
import json

class WakeWordDetector:
    def __init__(self, config):
        self.api_endpoint = "https://nls-gateway.cn-shanghai.aliyuncs.com"
        self.wake_word = "傻强"

    def detect_wake_word(self, audio_data):
        # 调用阿里云唤醒词API
        response = requests.post(self.api_endpoint, data={
            "audio": audio_data,
            "wake_word": self.wake_word
        })
        return response.json()
```

**避免的过度工程化**:
- ❌ 本地CNN唤醒词模型训练
- ❌ 复杂的音频特征提取
- ❌ 多唤醒词支持
- ❌ 自适应唤醒阈值算法

---

## 🛠️ 开发环境配置

### 环境初始化
```bash
# 1. 激活开发环境
source /home/sunrise/xlerobot/setup_xlerobot_env.sh

# 2. 安装最小化依赖
pip3 install -r requirements-sprint1-fixed.txt

# 3. 验证环境
python3 --version  # 应该是 Python 3.10.12
ros2 pkg list | head -5  # 验证ROS2功能
```

### 开发工具配置
```bash
# 代码检查 (可选)
pip3 install flake8 black

# 运行代码格式化
black src/xlerobot_phase1/

# 运行代码检查
flake8 src/xlerobot_phase1/
```

---

## 🧪 测试策略 (简化版)

### 单元测试
```python
# tests/test_audio_capture.py
import unittest
from xlerobot_phase1.audio_capture_node import AudioCaptureNode

class TestAudioCapture(unittest.TestCase):
    def setUp(self):
        self.node = AudioCaptureNode()

    def test_audio_quality_check(self):
        # 基础功能测试
        pass

    def test_capture_configuration(self):
        # 配置验证测试
        pass
```

### 集成测试
```bash
# 启动ROS2节点测试
ros2 run xlerobot_phase1 audio_capture_node

# 验证节点功能
ros2 topic echo /audio_data
```

---

## 📊 代码质量标准

### 代码行数控制
- **单个文件**: <200行
- **单个函数**: <30行
- **单个类**: <150行
- **总代码量**: Story 1.1 <150行, Story 1.2 <200行

### 性能指标
- **音频采集延迟**: <100ms
- **唤醒词检测延迟**: <200ms
- **内存使用**: <100MB (单节点)
- **CPU使用率**: <10% (空闲时)

### 代码质量
- **函数复杂度**: <10
- **代码重复率**: <5%
- **测试覆盖率**: >80%
- **文档覆盖率**: >90%

---

## 🚫 禁止的开发模式

### 过度工程化模式
- ❌ 创建复杂的配置管理系统
- ❌ 实现企业级日志和监控
- ❌ 开发自适应优化算法
- ❌ 构建通用的音频处理框架
- ❌ 实现复杂的错误恢复机制

### 不必要的技术
- ❌ 使用重型音频处理库 (如librosa)
- ❌ 实现本地机器学习模型
- ❌ 创建复杂的微服务架构
- ❌ 使用高级设计模式 (如工厂模式、观察者模式)

### 重复开发
- ❌ 重新实现已有的阿里云API功能
- ❌ 创建多个相似的音频处理类
- ❌ 重复的配置文件管理
- ❌ 多余的工具函数

---

## 🔄 开发工作流程

### 1. Story开发流程
```bash
# 1. 创建功能分支
git checkout -b story-1-1-audio-capture

# 2. 实现核心功能 (遵循代码行数限制)
# 编写音频采集节点 (~80行)
# 编写音频处理器 (~50行)
# 编写单元测试

# 3. 本地测试
source setup_xlerobot_env.sh
python3 tests/test_audio_capture.py

# 4. 集成测试
ros2 run xlerobot_phase1 audio_capture_node

# 5. 代码审查
# 检查代码行数 <150行
# 检查是否遵循简化原则

# 6. 提交代码
git add .
git commit -m "feat: implement Story 1.1 audio capture system (~150 lines)"
```

### 2. 质量检查清单
- [ ] 代码行数在限制范围内
- [ ] 无过度工程化功能
- [ ] 单元测试通过
- [ ] 集成测试通过
- [ ] 性能指标达标
- [ ] 代码文档完整

---

## 📞 开发支持

### 常见问题解决
1. **音频设备问题**: 检查 `/dev/audio*` 设备权限
2. **阿里云API调用**: 验证网络连接和API密钥
3. **ROS2节点问题**: 检查环境变量和路径配置
4. **性能问题**: 使用 `top` 和 `htop` 监控资源使用

### 调试技巧
```bash
# 启用详细日志
export RCUTILS_LOGGING_SEVERITY=DEBUG

# 监控系统资源
htop

# 检查ROS2节点状态
ros2 node list
ros2 node info /audio_capture_node
```

---

## 🎯 成功标准

### Story完成标准
- ✅ 功能按需求实现
- ✅ 代码行数在目标范围内
- ✅ 单元测试和集成测试通过
- ✅ 性能指标达标
- ✅ 代码审查通过
- ✅ 文档更新完成

### 迭代1完成标准
- ✅ 所有4个Stories完成
- ✅ 总代码量 <700行
- ✅ 完全依赖阿里云API工作
- ✅ 语音交互端到端测试通过
- ✅ 系统稳定运行24小时无故障

---

_开发指导版本: v2.0_
_最后更新: 2025-11-08_
_架构原则: 简单优先，避免过度工程化_
_适用范围: XleRobot 迭代1开发_