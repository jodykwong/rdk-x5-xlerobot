# ASR服务技术规格文档

**文档编号**: XLR-ASR-SPEC-20251110-001
**项目名称**: XleRobot 家用机器人控制系统
**文档类型**: 技术规格文档
**创建日期**: 2025-11-10
**版本**: v1.0
**作者**: Claude Code

---

## 📋 概述

本文档详细描述了XleRobot项目Epic 1中ASR（自动语音识别）服务的完整技术规格，包括架构设计、技术栈、性能指标、接口规范等。该ASR服务专门为粤语语音交互优化，采用纯在线架构设计。

---

## 🏗️ ASR服务架构

### 整体架构图

```
┌─────────────────────────────────────────────────────────────┐
│                  XleRobot ASR完整服务系统                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   音频输入层   │    │   音频处理层   │    │   云端识别层   │  │
│  │              │    │              │    │              │  │
│  │ • PyAudio    │───▶│ • VAD语音检测 │───▶│ • 阿里云ASR   │  │
│  │ • 麦克风采集   │    │ • 格式转换    │    │ • 粤语模型    │  │
│  │ • 16kHz/16bit│    │ • 降噪处理    │    │ • 实时WebSocket│  │
│  │ • WakeWord   │    │ • 音频分段    │    │ • 繁体字输出   │  │
│  │   Detector   │    │              │    │              │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│           │                   │                   │        │
│           ▼                   ▼                   ▼        │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                   智能处理层                             │  │
│  │                                                   │  │
│  │ • 状态机管理 (IDLE→LISTENING→WAKE_DETECTED→RECOGNIZING) │  │
│  │ • 多线程协调                                         │  │
│  │ • 错误处理和重试                                       │  │
│  │ • 缓冲区管理                                         │  │
│  └───────────────────────────────────────────────────────┘  │
│           │                   │                   │        │
│           ▼                   ▼                   ▼        │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   粤语回应层   │    │   ROS2集成层   │    │   应用接口层   │  │
│  │              │    │              │    │              │  │
│  │ • 阿里云TTS   │    │ • Topics/     │    │ • HTTP API   │  │
│  │ • 佳佳发音人   │    │   Services   │    │ • WebSocket  │  │
│  │ • 粤语回应词库 │    │ • Actions    │    │ • 语音指令    │  │
│  │ • 情感化合成   │    │ • 状态监控    │    │ • 对话管理    │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 服务流程

#### 🎤 第一阶段：唤醒词检测
```
环境音 → 麦克风 → PyAudio → 音频流 (16kHz, 16-bit, mono)
    ↓
WakeWordDetector (基于能量+频谱特征检测)
    ↓
检测到"傻强" → 触发粤语回应: "傻强系度,老细有乜可以帮到你!"
    ↓
状态变更: IDLE → WAKE_DETECTED → LISTENING
```

#### 🎧 第二阶段：用户指令采集
```
延迟0.5秒 (让用户准备说话)
    ↓
麦克风录音 (3-5秒)
    ↓
ASRAudioProcessor (格式转换、VAD、降噪)
    ↓
处理后的音频数据 (PCM, 16kHz, 单声道)
```

#### 🧠 第三阶段：云端语音识别
```
音频数据 → 阿里云ASR服务 (WebSocket)
    ↓
• 自动Token认证
• 粤语Paraformer模型识别
• 繁体字输出，支持粤英混合
• 实时流式识别
    ↓
识别结果 (文字 + 置信度 + 时间戳)
```

#### 🗣️ 第四阶段：粤语智能回应
```
识别结果 → 简单规则处理 (Epic 1)
    ↓
• 关键词匹配 ("你好"、"早晨"、"谢谢"等)
• 情感化回应选择
• 上下文感知 (简单)
    ↓
粤语回应文本 + 阿里云TTS (佳佳发音人)
    ↓
粤语语音播放 + ROS2话题发布
```

---

## 🔧 技术栈规格

### 核心技术栈

| 层级 | 技术选型 | 功能描述 | 版本要求 |
|------|----------|----------|----------|
| **音频采集** | PyAudio + NumPy | 实时麦克风音频采集 | PyAudio>=0.2.11, NumPy>=1.21.0 |
| **唤醒检测** | 基于能量+频谱特征 | 本地轻量级算法 | 自研算法 |
| **语音识别** | 阿里云NLS ASR | 粤语Paraformer模型 | API v2.0 |
| **语音合成** | 阿里云NLS TTS | 佳佳粤语女声发音人 | API v2.0 |
| **实时通信** | WebSocket协议 | 低延迟双向通信 | RFC 6455 |
| **系统集成** | ROS2 (rclpy) | 机器人通信框架 | ROS2 Humble |
| **并发处理** | Python多线程 | 实时音频流处理 | Python>=3.10 |

### 音频数据格式

```
采样率: 16000 Hz
位深度: 16-bit
通道数: 1 (单声道)
格式: PCM (WAV容器)
编码: 无压缩
缓冲区: 1024-4096 样本
字节序: Little Endian
```

### 阿里云服务集成

#### ASR配置
```yaml
语音识别配置:
  模型: paraformer-v1-cantonese-16k-common
  语言: 粤语(繁体)
  格式: PCM
  采样率: 16000
  协议: WebSocket
  输出格式: 繁体字
  支持语言混合: 粤英混合
```

#### TTS配置
```yaml
语音合成配置:
  发音人: jiajia (佳佳)
  语言: 粤语方言
  格式: WAV
  采样率: 16000
  音量: 100%
  语速: 0.0 (正常)
  语调: 0.0 (正常)
```

#### 认证机制
```yaml
Token认证:
  获取方式: 阿里云SDK getToken()
  缓存策略: 内存缓存 + 文件缓存
  刷新时机: 提前5分钟刷新
  有效期: 1小时
  重试策略: 指数退避
```

### 通信协议设计

```
1. Token认证: HTTPS + 自动刷新
   - 端点: https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts
   - 方法: POST
   - 认证: Bearer Token

2. ASR识别: WebSocket实时流式
   - 端点: wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1
   - 协议: WebSocket
   - 数据格式: JSON + Base64音频

3. TTS合成: HTTPS RESTful API
   - 端点: https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts
   - 方法: POST
   - 响应: 二进制音频流

4. ROS2通信: DDS (数据分发服务)
   - QoS: RELIABLE + VOLATILE
   - 深度: 10
   - 历史记录: 无
```

---

## 📊 性能指标

### 响应时间指标

| 操作类型 | 目标延迟 | 测量方式 | 验收标准 |
|----------|----------|----------|----------|
| **唤醒检测延迟** | < 200ms | 音频输入→检测结果 | 安静环境>90% |
| **语音识别延迟** | < 2秒 | 音频结束→结果输出 | 标准语音>95% |
| **TTS合成延迟** | < 1秒 | 文本输入→音频输出 | 粤语文本>95% |
| **端到端响应** | < 3秒 | 用户说话→系统回应 | 完整交互>90% |
| **状态切换延迟** | < 50ms | 状态变更→通知 | 所有状态>99% |

### 准确率指标

| 测试项目 | 目标准确率 | 测试环境 | 测试方法 |
|----------|------------|----------|----------|
| **唤醒词检测** | > 90% | 安静环境 | 100次测试 |
| **粤语识别** | > 95% | 标准环境 | 混合语音测试 |
| **噪声环境识别** | > 80% | 40-60dB噪声 | 噪声干扰测试 |
| **粤语词汇覆盖** | > 85% | 标准词汇表 | 常用词测试 |
| **繁体字输出** | > 98% | 标准文本 | 字符准确性 |

### 资源使用指标

| 资源类型 | 目标值 | 监控方式 | 告警阈值 |
|----------|--------|----------|----------|
| **CPU使用率** | < 30% | 系统监控 | > 50% |
| **内存占用** | < 100MB | 进程监控 | > 150MB |
| **网络带宽** | < 1Mbps | 流量监控 | > 2Mbps |
| **音频缓冲区** | < 100ms | 延迟监控 | > 200ms |
| **并发连接数** | 5个 | 连接监控 | > 10个 |

---

## 🎯 ROS2接口规范

### Topics接口

#### /audio/processed
```python
# 处理后音频数据
消息类型: audio_msg/AudioData
字段说明:
  - data: bytes (音频数据)
  - sample_rate: uint32 (采样率)
  - channels: uint32 (通道数)
  - bits_per_sample: uint32 (位深度)
  - frame_count: uint32 (帧数)
QoS: RELIABLE, DEPTH=10
```

#### /asr/result
```python
# ASR识别结果
消息类型: audio_msg/ASRResult
字段说明:
  - header: std_msgs/Header (时间戳)
  - text: string (识别文本)
  - confidence: float32 (置信度 0-1)
  - begin_time: int32 (开始时间 ms)
  - end_time: int32 (结束时间 ms)
  - status_code: int32 (状态码)
  - message: string (状态消息)
QoS: RELIABLE, DEPTH=10
```

#### /asr/status
```python
# ASR系统状态
消息类型: audio_msg/ASRStatus
字段说明:
  - header: std_msgs/Header (时间戳)
  - is_initialized: bool (是否初始化)
  - is_processing: bool (是否处理中)
  - language: string (识别语言)
  - sample_rate: uint32 (采样率)
  - format: string (音频格式)
  - total_requests: uint32 (总请求数)
  - successful_requests: uint32 (成功请求数)
  - failed_requests: uint32 (失败请求数)
  - uptime: float32 (运行时间 秒)
  - audio_buffer_size: uint32 (音频缓冲区大小)
  - active_goals: uint32 (活跃目标数)
QoS: VOLATILE, DEPTH=1
```

### Services接口

#### /asr/configure
```python
# ASR配置服务
服务类型: audio_msg/ASRConfigure
请求字段:
  - language: string (识别语言)
  - sample_rate: uint32 (采样率)
  - format: string (音频格式)
  - enable_continuous: bool (启用连续识别)
  - confidence_threshold: float32 (置信度阈值)

响应字段:
  - success: bool (配置是否成功)
  - message: string (状态消息)
```

### Actions接口

#### /asr/continuous_recognition
```python
# 连续语音识别动作
动作类型: audio_msg/ContinuousRecognition

目标字段:
  - timeout: float32 (超时时间 秒)
  - max_duration: float32 (最大持续时间 秒)
  - silence_timeout: float32 (静音超时 秒)

反馈字段:
  - intermediate_text: string (中间识别结果)
  - confidence: float32 (置信度)
  - is_final: bool (是否最终结果)

结果字段:
  - success: bool (识别是否成功)
  - message: string (状态消息)
  - total_duration: float32 (总持续时间)
  - recognized_text: string (最终识别文本)
```

---

## 🗣️ 粤语回应词库

### 唤醒词回应
```python
WAKE_WORD_RESPONSES = {
    "傻强": "傻强系度,老细有乜可以帮到你!",  # 主要回应词
    "小强": "小强嚟啦,老细有乜吩咐?",        # 备用唤醒词
    "机器人": "机器人听到你,请讲!"         # 通用唤醒词
}
```

### 识别后回应词库

#### 问候类回应
```python
GREETING_RESPONSES = [
    "早晨老细,今日几好天氣呀!",           # 早晨老板，今天天气很好呀！
    "你好呀,有咩可以帮到你呢?",           # 你好呀，有什么可以帮到你呢？
    "哈囉,老细!有乜可以为你服务?"         # 哈啰，老板！有什么可以为你服务？
]
```

#### 确认类回应
```python
ACKNOWLEDGMENT_RESPONSES = [
    "收到老细,我明晒你讲嘅嘢!",           # 收到老板，我明明白你讲的东西！
    "好嘅,冇问题,即刻办!",               # 好的，没问题，立刻办！
    "OK老细,搞掂佢!"                     # OK老板，搞定它！
]
```

#### 感谢类回应
```python
THANKS_RESPONSES = [
    "唔使客氣,老细!有乜再叫我!",          # 不用客气，老板！有什么再叫我！
    "应该嘅,老细!",                      # 应该的，老板！
    "随时为你服务,老细!"                  # 随时为你服务，老板！
]
```

#### 询问类回应
```python
INQUIRY_RESPONSES = [
    "老细你想點樣呢?",                    # 老板你想怎么样呢？
    "请问我可以点样帮你?",                # 请问我可以怎么帮你？
    "有咩特别需要嘅服务吗?"              # 有什么特别需要的服务吗？
]
```

#### 默认回应
```python
DEFAULT_RESPONSES = [
    "我聽到啦，請繼續講!",                # 我听到啦，请继续讲！
    "明白,請講詳細啲!",                  # 明白，请讲详细点！
    "收到,老细請講!",                      # 收到，老板请讲！
    "好嘅,有咩可以帮你?"                  # 好的，有什么可以帮你？
]
```

---

## 🔧 系统配置

### ASR系统配置
```yaml
asr_system:
  # 音频参数
  sample_rate: 16000
  chunk_size: 1024
  channels: 1
  bit_depth: 16

  # 监听参数
  listen_duration: 5.0      # 单次监听时长(秒)
  max_silence_duration: 3.0  # 最大静音时长(秒)

  # 识别参数
  recognition_duration: 3.0  # 识别录音时长(秒)
  confidence_threshold: 0.5  # 置信度阈值

  # 音频参数
  wake_volume: 1.0          # 唤醒音量
  done_volume: 1.0          # 完成音量
  error_volume: 1.0         # 错误音量
  response_volume: 1.0      # 回应音量
```

### 阿里云API配置
```yaml
aliyun_nls:
  # 认证配置
  app_key: "${ALIYUN_NLS_APP_KEY}"
  app_secret: "${ALIYUN_NLS_APP_SECRET}"
  region: "cn-shanghai"

  # ASR配置
  asr:
    url: "wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1"
    model: "paraformer-v1-cantonese-16k-common"
    format: "pcm"
    sample_rate: 16000
    language: "cantonese"

  # TTS配置
  tts:
    url: "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts"
    voice: "jiajia"
    format: "wav"
    sample_rate: 16000
    volume: 100
    speech_rate: 0
    pitch_rate: 0
```

### 唤醒词配置
```yaml
wake_word:
  # 检测参数
  sensitivity: 0.7
  min_duration_ms: 500
  window_size_ms: 2000
  hop_size_ms: 100

  # 唤醒词列表
  wake_words:
    - name: "傻强"
      language: "cantonese"
      threshold: 0.85

  # 唤醒后行为
  wake_response: "傻强系度,老细有乜可以帮到你!"
  response_delay: 0.5  # 唤醒后延迟识别时间(秒)
```

---

## 📈 监控和日志

### 关键监控指标
```yaml
monitoring:
  # 性能指标
  metrics:
    - name: "asr_latency"
      type: "histogram"
      unit: "seconds"
      labels: ["language", "model"]

    - name: "asr_accuracy"
      type: "gauge"
      unit: "percent"
      labels: ["environment", "noise_level"]

    - name: "tts_latency"
      type: "histogram"
      unit: "seconds"
      labels: ["voice", "text_length"]

  # 系统指标
  system:
    - cpu_usage_percent
    - memory_usage_mb
    - network_bandwidth_mbps
    - audio_buffer_size
    - active_connections
```

### 日志级别和格式
```yaml
logging:
  # 日志级别
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

  # 日志文件
  file: "/var/log/xlerobot/asr_service.log"
  max_size: "100MB"
  backup_count: 5

  # 特殊日志
  performance:
    enabled: true
    format: "json"
    include_metrics: true

  security:
    enabled: true
    include_api_keys: false
    audit_trail: true
```

---

## 🛠️ 部署和维护

### 系统要求
```yaml
requirements:
  # 硬件要求
  hardware:
    cpu: ">= 2 cores"
    memory: ">= 4GB RAM"
    storage: ">= 10GB"
    network: ">= 1Mbps"

  # 软件要求
  software:
    os: "Ubuntu 22.04 LTS"
    python: ">= 3.10"
    ros2: "Humble Hawksbill"

  # 依赖包
  dependencies:
    - "PyAudio>=0.2.11"
    - "numpy>=1.21.0"
    - "requests>=2.28.0"
    - "rclpy>=3.3.0"
    - "aliyun-python-sdk-nls>=2.2.0"
```

### 部署脚本
```bash
#!/bin/bash
# ASR服务部署脚本

# 1. 环境准备
source /opt/ros/humble/setup.bash
cd /home/sunrise/xlerobot

# 2. 安装依赖
pip3 install -r requirements.txt

# 3. 配置环境变量
export ALIYUN_NLS_APP_KEY="your_app_key"
export ALIYUN_NLS_APP_SECRET="your_app_secret"

# 4. 构建ROS2工作空间
colcon build --packages-select xlerobot_phase1

# 5. 启动ASR服务
source install/setup.bash
ros2 run xlerobot_phase1 asr_service_node
```

### 维护操作
```bash
# 状态检查
ros2 topic echo /asr/status

# 性能监控
ros2 run xlerobot_phase1 asr_performance_monitor

# 配置更新
ros2 service call /asr/configure audio_msg/ASRConfigure "{language: 'cantonese', sample_rate: 16000}"

# 日志查看
tail -f /var/log/xlerobot/asr_service.log

# 服务重启
ros2 service call /asr/restart std_srvs/Trigger
```

---

## 📝 变更记录

| 版本 | 日期 | 变更内容 | 作者 |
|------|------|----------|------|
| v1.0 | 2025-11-10 | 初始版本创建 | Claude Code |
| | | 完整ASR架构设计 | |
| | | 粤语回应词库定义 | |
| | | 技术规格详细说明 | |

---

## 🔗 相关文档

- [Epic 1语音交互系统设计](./epics-phase2-xlerobot.md#epic-1)
- [Story 1.1音频采集系统](./stories/story-1-1-audio-capture-system.md)
- [Story 1.2基础语音唤醒](./stories/story-1-2-basic-voice-wake-up.md)
- [Story 1.3基础语音识别](./story-1-3-implementation.md)
- [阿里云NLS API文档](https://help.aliyun.com/zh/nls/)
- [ROS2官方文档](https://docs.ros.org/en/humble/)

---

**文档状态**: ✅ 已完成
**审核状态**: 待审核
**下次更新**: 根据实现进度更新

---

*本文档为XleRobot项目ASR服务的官方技术规格文档，如有疑问请联系开发团队。*