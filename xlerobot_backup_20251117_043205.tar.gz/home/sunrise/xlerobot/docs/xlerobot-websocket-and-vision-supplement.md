# XLeRobot WebSocket通信与视觉交互补充文档

**文档版本**: 1.0
**创建日期**: 2025-11-16
**适用版本**: Epic 1 (纯在线架构)
**补充内容**: WebSocket通信架构 + 视觉交互流程

---

## 📋 目录

1. [WebSocket通信架构](#1-websocket通信架构)
2. [视觉交互完整流程](#2-视觉交互完整流程)
3. [多模态交互场景](#3-多模态交互场景)
4. [完整数据流示例](#4-完整数据流示例)

---

## ⚠️ 重要说明

本文档补充了主架构文档中缺少的两个关键部分：

1. **ASR/TTS使用WebSocket通信**，而非REST API
2. **视觉交互流程**，系统支持语音+视觉多模态交互

---

## 1. WebSocket通信架构

### 1.1 为什么使用WebSocket？

阿里云NLS服务**必须使用WebSocket协议**，HTTP REST API无法正常工作。

**WebSocket优势**:
- ✅ 支持**流式处理**：实时语音识别和合成
- ✅ 支持**双向通信**：可以接收中间结果
- ✅ 降低**延迟**：避免HTTP请求/响应开销
- ✅ 支持**长音频**：可以持续传输音频流

### 1.2 ASR WebSocket连接

#### 连接信息

```yaml
WebSocket端点: wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1
协议: WebSocket
认证方式: Token (通过SDK自动处理)
SDK: aliyun-nls-python-sdk
核心类: NlsSpeechRecognizer
```

#### 连接流程

```
┌─────────────────────────────────────────────────────────────┐
│          阿里云ASR WebSocket连接完整流程                      │
└─────────────────────────────────────────────────────────────┘

第1步: Token获取
┌──────────────────────────────────────┐
│ 1. 使用AccessKey获取Token             │
│    from nls.token import getToken     │
│    token = getToken(key_id, secret)   │
│                                      │
│ 2. Token有效期: 24小时                │
│ 3. 自动刷新机制: 提前30分钟刷新        │
└──────────────────────────────────────┘
           │
           ▼
第2步: WebSocket连接建立
┌──────────────────────────────────────┐
│ 1. 创建NlsSpeechRecognizer实例        │
│    recognizer = NlsSpeechRecognizer(  │
│        token=token,                   │
│        appkey=app_key,                │
│        on_start=callback,             │
│        on_result_changed=callback,    │
│        on_completed=callback,         │
│        on_error=callback              │
│    )                                  │
│                                      │
│ 2. 连接到WSS端点                      │
│    wss://nls-gateway.cn-shanghai      │
│    .aliyuncs.com/ws/v1                │
│                                      │
│ 3. 握手认证 (SDK自动完成)             │
└──────────────────────────────────────┘
           │
           ▼
第3步: 音频流传输
┌──────────────────────────────────────┐
│ 1. 音频格式要求:                      │
│    - 格式: PCM                        │
│    - 采样率: 16000 Hz                 │
│    - 位深: 16-bit                     │
│    - 声道: 单声道 (mono)              │
│                                      │
│ 2. 开始识别                           │
│    recognizer.start(                  │
│        aformat="pcm",                 │
│        sample_rate=16000,             │
│        enable_intermediate_result=True│
│    )                                  │
│                                      │
│ 3. 发送音频数据                       │
│    recognizer.send_audio(audio_data)  │
│    (可以多次调用，流式发送)           │
│                                      │
│ 4. 结束识别                           │
│    recognizer.stop()                  │
└──────────────────────────────────────┘
           │
           ▼
第4步: 接收识别结果
┌──────────────────────────────────────┐
│ 1. on_start() - 识别开始              │
│    日志: "🎤 识别开始"                 │
│                                      │
│ 2. on_result_changed() - 中间结果     │
│    {                                 │
│      "header": {...},                │
│      "payload": {                    │
│        "index": 1,                   │
│        "time": 1000,                 │
│        "result": "今日"               │
│      }                                │
│    }                                 │
│                                      │
│ 3. on_completed() - 最终结果          │
│    {                                 │
│      "header": {...},                │
│      "payload": {                    │
│        "result": "今日天气点样",       │
│        "confidence": 95.2            │
│      }                                │
│    }                                 │
│                                      │
│ 4. on_error() - 错误处理              │
│    处理连接错误、超时、格式错误等      │
└──────────────────────────────────────┘
```

#### 代码实现示例

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阿里云ASR WebSocket连接示例"""

import sys
sys.path.append('/home/sunrise/.local/lib/python3.10/site-packages')

from nls.token import getToken
from nls.speech_recognizer import NlsSpeechRecognizer
import json

class AliyunASRWebSocket:
    """阿里云ASR WebSocket连接器"""

    def __init__(self, access_key_id, access_key_secret, app_key):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.app_key = app_key
        self.token = None
        self.recognizer = None
        self.result_text = ""

    def get_token(self):
        """获取Token"""
        self.token = getToken(self.access_key_id, self.access_key_secret)
        print(f"✅ Token获取成功: {self.token[:20]}...")
        return self.token

    def on_start(self, message, *args):
        """识别开始回调"""
        print("🎤 ASR识别开始")

    def on_result_changed(self, message, *args):
        """中间结果回调"""
        try:
            result = json.loads(message)
            if 'payload' in result and 'result' in result['payload']:
                text = result['payload']['result']
                print(f"🔄 中间结果: {text}")
        except Exception as e:
            print(f"❌ 中间结果解析失败: {e}")

    def on_completed(self, message, *args):
        """识别完成回调"""
        try:
            result = json.loads(message)
            if 'payload' in result and 'result' in result['payload']:
                self.result_text = result['payload']['result']
                confidence = result['payload'].get('confidence', 0)
                print(f"✅ 最终结果: '{self.result_text}' (置信度: {confidence}%)")
        except Exception as e:
            print(f"❌ 最终结果解析失败: {e}")

    def on_error(self, message, *args):
        """错误回调"""
        print(f"❌ ASR错误: {message}")

    def create_recognizer(self):
        """创建识别器"""
        if not self.token:
            self.get_token()

        self.recognizer = NlsSpeechRecognizer(
            token=self.token,
            appkey=self.app_key,
            on_start=self.on_start,
            on_result_changed=self.on_result_changed,
            on_completed=self.on_completed,
            on_error=self.on_error
        )
        print("✅ ASR WebSocket连接器创建成功")
        return self.recognizer

    def recognize_audio(self, audio_file_path):
        """识别音频文件"""
        import wave

        # 创建识别器
        if not self.recognizer:
            self.create_recognizer()

        # 读取音频文件
        with wave.open(audio_file_path, 'rb') as wav_file:
            audio_data = wav_file.readframes(wav_file.getnframes())

        # 开始识别
        self.recognizer.start(
            aformat="pcm",
            sample_rate=16000,
            enable_intermediate_result=True
        )

        # 发送音频数据
        self.recognizer.send_audio(audio_data)

        # 结束识别
        self.recognizer.stop()

        # 等待结果
        import time
        timeout = 10
        start_time = time.time()
        while not self.result_text and (time.time() - start_time) < timeout:
            time.sleep(0.1)

        return self.result_text

# 使用示例
if __name__ == "__main__":
    asr = AliyunASRWebSocket(
        access_key_id="LTAI5tQ4E2YNzZkGn9g1JqeY",
        access_key_secret="Hr1xZdcdz3D9OgFnH1nvWz5rldXVeI",
        app_key="4G5BCMccTCW8nC8w"
    )

    result = asr.recognize_audio("test_audio.wav")
    print(f"识别结果: {result}")
```

### 1.3 TTS WebSocket连接

#### 连接信息

```yaml
WebSocket端点: wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1
协议: WebSocket
认证方式: Token (与ASR共用)
SDK: aliyun-nls-python-sdk
核心类: NlsSpeechSynthesizer
```

#### 连接流程

```
┌─────────────────────────────────────────────────────────────┐
│          阿里云TTS WebSocket连接完整流程                      │
└─────────────────────────────────────────────────────────────┘

第1步: 使用相同Token
┌──────────────────────────────────────┐
│ Token复用ASR Token                    │
│ (ASR和TTS共用同一个Token Manager)     │
└──────────────────────────────────────┘
           │
           ▼
第2步: WebSocket连接建立
┌──────────────────────────────────────┐
│ 1. 创建NlsSpeechSynthesizer实例       │
│    synthesizer = NlsSpeechSynthesizer(│
│        token=token,                   │
│        appkey=app_key,                │
│        on_start=callback,             │
│        on_audio_data=callback,        │
│        on_completed=callback,         │
│        on_error=callback              │
│    )                                  │
│                                      │
│ 2. 连接到WSS端点 (与ASR相同)         │
└──────────────────────────────────────┘
           │
           ▼
第3步: 发送文本
┌──────────────────────────────────────┐
│ 1. 设置合成参数                       │
│    synthesizer.start(                 │
│        voice="jiajia",  # 粤语音色    │
│        aformat="wav",                 │
│        sample_rate=16000,             │
│        volume=50,                     │
│        speech_rate=0,  # 语速正常     │
│        text="今日天气晴朗"             │
│    )                                  │
└──────────────────────────────────────┘
           │
           ▼
第4步: 接收音频流
┌──────────────────────────────────────┐
│ 1. on_audio_data() - 音频数据流       │
│    持续接收音频片段                    │
│    可边接收边播放 (流式播放)           │
│                                      │
│ 2. on_completed() - 合成完成          │
│    所有音频数据接收完毕                │
│                                      │
│ 3. on_error() - 错误处理              │
└──────────────────────────────────────┘
```

#### TTS代码示例

```python
from nls.speech_synthesizer import NlsSpeechSynthesizer

class AliyunTTSWebSocket:
    """阿里云TTS WebSocket连接器"""

    def __init__(self, token, app_key):
        self.token = token
        self.app_key = app_key
        self.audio_data = bytearray()

    def on_start(self, message, *args):
        """合成开始回调"""
        print("🎵 TTS合成开始")

    def on_audio_data(self, data, *args):
        """音频数据回调 - 流式接收"""
        self.audio_data.extend(data)
        print(f"📥 接收音频数据: {len(data)} 字节")

    def on_completed(self, message, *args):
        """合成完成回调"""
        print(f"✅ TTS合成完成，总计 {len(self.audio_data)} 字节")

    def on_error(self, message, *args):
        """错误回调"""
        print(f"❌ TTS错误: {message}")

    def synthesize(self, text):
        """合成语音"""
        self.audio_data = bytearray()

        synthesizer = NlsSpeechSynthesizer(
            token=self.token,
            appkey=self.app_key,
            on_start=self.on_start,
            on_audio_data=self.on_audio_data,
            on_completed=self.on_completed,
            on_error=self.on_error
        )

        synthesizer.start(
            voice="jiajia",  # 粤语佳佳音色
            aformat="wav",
            sample_rate=16000,
            volume=50,
            speech_rate=0,
            text=text
        )

        # 等待合成完成
        import time
        timeout = 30
        start_time = time.time()
        while len(self.audio_data) == 0 and (time.time() - start_time) < timeout:
            time.sleep(0.1)

        return bytes(self.audio_data)
```

### 1.4 WebSocket连接管理

#### 连接状态监控

```python
class WebSocketConnectionManager:
    """WebSocket连接管理器"""

    def __init__(self):
        self.asr_connected = False
        self.tts_connected = False
        self.last_asr_ping = 0
        self.last_tts_ping = 0

    def check_health(self):
        """检查连接健康状态"""
        import time
        current_time = time.time()

        # ASR连接检查
        if current_time - self.last_asr_ping > 60:
            print("⚠️ ASR WebSocket连接可能已断开")
            return False

        # TTS连接检查
        if current_time - self.last_tts_ping > 60:
            print("⚠️ TTS WebSocket连接可能已断开")
            return False

        return True

    def reconnect_if_needed(self):
        """必要时重新连接"""
        if not self.check_health():
            print("🔄 检测到连接问题，正在重新连接...")
            # 重新创建recognizer和synthesizer实例
```

---

## 2. 视觉交互完整流程

### 2.1 视觉系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                  XLeRobot视觉交互系统                         │
└─────────────────────────────────────────────────────────────┘

硬件层          软件层(ROS2)         云端服务
┌──────────┐    ┌────────────┐    ┌─────────────────┐
│ IMX219   │───→│ camera     │───→│ 临时文件存储     │
│ 摄像头    │    │ driver     │    │ /tmp/*.jpg      │
│ 1080p    │    │            │    └─────────────────┘
│ 30fps    │    └────────────┘              │
└──────────┘            │                   │
                        │ ROS2 Topic         │
                        │ /camera/image_raw  │
                        ▼                   ▼
                ┌────────────────┐    ┌─────────────────┐
                │ vision_llm_    │───→│  Qwen-VL API   │
                │ node           │    │  (HTTP/2)      │
                │                │    │  dashscope.    │
                │ - 图像缓存     │    │  aliyuncs.com  │
                │ - 会话管理     │    └─────────────────┘
                │ - 上下文处理   │              │
                └────────────────┘              │
                        │                       │
                        │ /vision/query         │
                        │ (用户视觉问题)         │
                        │                       │
                        │ /vision/response      │
                        │ (视觉理解结果)         │
                        ▼                       ▼
                ┌────────────────┐    ┌─────────────────┐
                │ coordinator    │    │ Qwen3-VL-Plus  │
                │                │    │ 多模态模型     │
                └────────────────┘    │                │
                                     │ - 图像理解     │
                                     │ - 场景描述     │
                                     │ - 物体识别     │
                                     │ - 粤语回复     │
                                     └─────────────────┘
```

### 2.2 摄像头数据流

#### 摄像头启动流程

```bash
# 1. 检查摄像头设备
ls /dev/video*
# 输出: /dev/video0 /dev/video1

# 2. 查看摄像头信息
v4l2-ctl --list-devices
# 输出:
# IMX219 Camera (platform:rkisp0-vir0):
#     /dev/video0
#     /dev/video1

# 3. 启动ROS2摄像头驱动
ros2 run v4l2_camera v4l2_camera_node \
    --ros-args \
    -p video_device:=/dev/video0 \
    -p image_size:="[1920,1080]" \
    -p camera_frame_id:=camera_link \
    -p pixel_format:=YUYV
```

#### 图像消息格式

```python
# ROS2 sensor_msgs/Image 消息结构
{
    "header": {
        "stamp": {
            "sec": 1699999999,
            "nanosec": 123456789
        },
        "frame_id": "camera_link"
    },
    "height": 1080,
    "width": 1920,
    "encoding": "bgr8",  # OpenCV BGR格式
    "is_bigendian": 0,
    "step": 5760,  # 1920 * 3 (每像素3字节)
    "data": [...]  # 原始图像数据
}
```

### 2.3 视觉LLM节点实现

#### 核心功能

```python
#!/usr/bin/env python3.10
"""视觉LLM节点 - 完整实现"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import tempfile

class VisionLLMNode(Node):
    """视觉LLM ROS2节点"""

    def __init__(self):
        super().__init__('vision_llm_node')

        # 核心组件
        self.bridge = CvBridge()
        self.current_image_path = None
        self.vision_client = QwenVLPlusClient()

        # 订阅摄像头图像
        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )

        # 订阅视觉查询
        self.query_sub = self.create_subscription(
            String,
            '/vision/query',
            self.query_callback,
            10
        )

        # 发布视觉响应
        self.response_pub = self.create_publisher(
            String,
            '/vision/response',
            10
        )

        self.get_logger().info("✅ 视觉LLM节点启动成功")

    def image_callback(self, msg):
        """接收并缓存最新图像"""
        try:
            # 转换ROS图像为OpenCV格式
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")

            # 保存临时文件
            if self.current_image_path:
                os.remove(self.current_image_path)

            temp_file = tempfile.NamedTemporaryFile(
                suffix='.jpg',
                delete=False
            )
            cv2.imwrite(temp_file.name, cv_image)
            self.current_image_path = temp_file.name

            self.get_logger().debug(f"📸 图像已更新: {self.current_image_path}")

        except Exception as e:
            self.get_logger().error(f"图像处理失败: {e}")

    def query_callback(self, msg):
        """处理视觉查询"""
        if not self.current_image_path:
            self.get_logger().warn("⚠️ 没有可用图像")
            response = String()
            response.data = "错误：没有可用图像，请先拍摄照片"
            self.response_pub.publish(response)
            return

        try:
            # 调用Qwen-VL API
            result = self.vision_client.query(
                image_path=self.current_image_path,
                question=msg.data
            )

            # 发布结果
            response = String()
            response.data = result
            self.response_pub.publish(response)

            self.get_logger().info(f"✅ 视觉查询成功: {msg.data}")

        except Exception as e:
            self.get_logger().error(f"视觉查询失败: {e}")
```

### 2.4 Qwen-VL API集成

#### API调用流程

```
┌─────────────────────────────────────────────────────────────┐
│              Qwen-VL API调用完整流程                          │
└─────────────────────────────────────────────────────────────┘

第1步: 图像预处理
┌──────────────────────────────────────┐
│ 1. 读取本地图像文件                   │
│ 2. Base64编码                        │
│ 3. 构建图像URL                        │
│    - 本地路径: file:///path/to/img   │
│    - 或base64: data:image/jpeg;...   │
└──────────────────────────────────────┘
           │
           ▼
第2步: 构建API请求
┌──────────────────────────────────────┐
│ POST https://dashscope.aliyuncs.com   │
│      /compatible-mode/v1/chat/        │
│      completions                      │
│                                      │
│ Headers:                              │
│   Authorization: Bearer $QWEN_API_KEY │
│   Content-Type: application/json      │
│                                      │
│ Body:                                 │
│ {                                     │
│   "model": "qwen3-vl-plus",           │
│   "messages": [                       │
│     {                                 │
│       "role": "user",                 │
│       "content": [                    │
│         {                             │
│           "type": "image_url",        │
│           "image_url": {              │
│             "url": "base64_or_path"   │
│           }                            │
│         },                            │
│         {                             │
│           "type": "text",             │
│           "text": "呢个系咩嚟嘅？"     │
│         }                             │
│       ]                               │
│     }                                 │
│   ]                                   │
│ }                                     │
└──────────────────────────────────────┘
           │
           ▼
第3步: 接收响应
┌──────────────────────────────────────┐
│ {                                     │
│   "id": "chatcmpl-123",               │
│   "object": "chat.completion",        │
│   "created": 1699999999,              │
│   "model": "qwen3-vl-plus",           │
│   "choices": [                        │
│     {                                 │
│       "index": 0,                     │
│       "message": {                    │
│         "role": "assistant",          │
│         "content": "呢个系一杯咖啡..."│
│       },                              │
│       "finish_reason": "stop"         │
│     }                                 │
│   ],                                  │
│   "usage": {                          │
│     "prompt_tokens": 150,             │
│     "completion_tokens": 30,          │
│     "total_tokens": 180               │
│   }                                   │
│ }                                     │
└──────────────────────────────────────┘
```

#### Qwen-VL客户端代码

```python
import os
import base64
import requests
from typing import Optional

class QwenVLPlusClient:
    """Qwen3-VL-Plus 多模态API客户端"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("QWEN_API_KEY")
        self.endpoint = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
        self.model = "qwen3-vl-plus"

    def encode_image(self, image_path: str) -> str:
        """将图像编码为Base64"""
        with open(image_path, "rb") as image_file:
            encoded = base64.b64encode(image_file.read()).decode('utf-8')
            return f"data:image/jpeg;base64,{encoded}"

    def query(self, image_path: str, question: str, system_prompt: Optional[str] = None) -> str:
        """
        查询视觉模型

        Args:
            image_path: 图像文件路径
            question: 用户问题
            system_prompt: 系统提示（可选）

        Returns:
            模型回复文本
        """
        # 编码图像
        image_url = self.encode_image(image_path)

        # 构建消息
        messages = []

        # 系统提示
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        else:
            messages.append({
                "role": "system",
                "content": "你是一个友好的粤语语音助手，负责理解图像并用粤语回答问题。"
            })

        # 用户消息（图像+文本）
        messages.append({
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": image_url
                    }
                },
                {
                    "type": "text",
                    "text": question
                }
            ]
        })

        # API请求
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.model,
            "messages": messages
        }

        response = requests.post(
            self.endpoint,
            headers=headers,
            json=payload,
            timeout=30
        )

        response.raise_for_status()

        # 解析响应
        result = response.json()
        return result['choices'][0]['message']['content']
```

---

## 3. 多模态交互场景

### 3.1 纯语音交互场景

```
用户: "傻强"  (唤醒词)
系统: "傻强系度,老细有乜可以帮到你!"  (欢迎语)

用户: "今日天气点样？"
系统:
  1. ASR识别 (WebSocket) → "今日天气点样"
  2. LLM推理 (HTTP/2) → "今日广州天气晴朗..."
  3. TTS合成 (WebSocket) → 音频流
  4. 播放音频

时间线:
T+0.0s: 用户说"傻强"
T+0.5s: ASR检测到唤醒词
T+0.5s: 播放欢迎语
T+2.5s: 欢迎语播放完成
T+2.5s: 开始监听用户指令
T+3.0s: 用户说"今日天气点样"
T+4.0s: ASR识别完成
T+4.0s: 发送LLM请求
T+6.0s: LLM响应返回
T+6.0s: 发送TTS请求
T+7.0s: TTS合成完成
T+7.0s: 开始播放回复
T+10.0s: 播放完成
```

### 3.2 语音+视觉交互场景

```
用户: "傻强"
系统: "傻强系度,老细有乜可以帮到你!"

用户: "呢个系咩嚟嘅？"  (指着桌上的物品)
系统:
  1. ASR识别 → "呢个系咩嚟嘅"
  2. 检测到视觉查询关键词 ("呢个", "咩嚟嘅")
  3. 获取最新摄像头图像
  4. 发送到Qwen-VL API (图像+问题)
  5. 接收视觉理解结果 → "呢个系一杯咖啡，放喺桌面上..."
  6. TTS合成并播放

时间线:
T+0.0s: 用户说"傻强"
T+0.5s: 唤醒成功
T+2.5s: 用户说"呢个系咩嚟嘅"
T+3.5s: ASR识别完成
T+3.5s: 检测视觉查询，触发摄像头
T+3.6s: 发送图像到Qwen-VL API
T+5.6s: Qwen-VL响应返回
T+5.6s: TTS合成
T+6.6s: 播放回复
```

### 3.3 连续多模态交互

```
对话示例:

回合1 (纯语音):
用户: "傻强，你好呀"
系统: "你好！我系傻强，有咩可以帮到你？"

回合2 (视觉):
用户: "睇下呢张相片"
系统: "好嘅，我睇到一张相片... (描述图像内容)"

回合3 (带上下文的视觉):
用户: "相片入面有几多个人？"
系统: "有三个人喺度..."

回合4 (纯语音):
用户: "谢谢你"
系统: "唔使客气！"

上下文管理:
- 协调器维护对话历史
- 视觉LLM节点维护图像上下文
- 支持多轮对话引用
```

---

## 4. 完整数据流示例

### 4.1 多模态查询完整流程

```
场景: 用户问"呢杯咖啡系咩颜色？"

┌─────────────────────────────────────────────────────────────┐
│            多模态查询完整数据流 (带时间戳)                     │
└─────────────────────────────────────────────────────────────┘

T+0.0s - 用户语音输入
┌──────────────────────────────────────┐
│ 用户说话: "呢杯咖啡系咩颜色？"         │
│ 麦克风采集: 16kHz PCM音频流           │
└──────────────────────────────────────┘
           │
           ▼
T+1.0s - ASR WebSocket识别
┌──────────────────────────────────────┐
│ 1. ASR节点接收音频                    │
│ 2. 发送到WebSocket连接                │
│ 3. 中间结果: "呢杯..."                │
│ 4. 最终结果: "呢杯咖啡系咩颜色"        │
└──────────────────────────────────────┘
           │
           ▼ /voice_command
T+1.2s - 协调器处理
┌──────────────────────────────────────┐
│ 1. 接收ASR文本                        │
│ 2. 分析查询类型                       │
│ 3. 检测到视觉关键词: "呢杯"、"颜色"   │
│ 4. 决定使用多模态模式                 │
└──────────────────────────────────────┘
           │
           ├───────────┐
           │           │
           ▼           ▼
T+1.3s    获取图像    构建查询
┌────────────────┐  ┌────────────────┐
│ 1. 订阅        │  │ 1. 准备问题    │
│  /camera/      │  │    文本         │
│   image_raw    │  │                │
│ 2. 获取最新帧   │  │ 2. 准备上下文   │
│ 3. 保存临时文件 │  │                │
└────────────────┘  └────────────────┘
           │           │
           └─────┬─────┘
                 ▼
T+1.5s - 发送到Qwen-VL
┌──────────────────────────────────────┐
│ HTTP/2 POST to dashscope.aliyuncs.com │
│                                      │
│ Request:                              │
│ {                                     │
│   "model": "qwen3-vl-plus",           │
│   "messages": [                       │
│     {                                 │
│       "role": "user",                 │
│       "content": [                    │
│         {"type": "image_url", ...},   │
│         {"type": "text",              │
│          "text": "呢杯咖啡系咩颜色？"} │
│       ]                               │
│     }                                 │
│   ]                                   │
│ }                                     │
└──────────────────────────────────────┘
           │
           ▼
T+3.5s - Qwen-VL处理
┌──────────────────────────────────────┐
│ 云端多模态模型处理:                    │
│ 1. 图像特征提取                       │
│ 2. 文本语义理解                       │
│ 3. 跨模态理解                         │
│ 4. 生成粤语回复                       │
└──────────────────────────────────────┘
           │
           ▼
T+3.7s - 接收VL响应
┌──────────────────────────────────────┐
│ Response:                             │
│ {                                     │
│   "choices": [{                       │
│     "message": {                      │
│       "content": "呢杯咖啡系啡色嘅，   │
│                   表面有奶泡..."      │
│     }                                 │
│   }]                                  │
│ }                                     │
└──────────────────────────────────────┘
           │
           ▼ /llm_response
T+3.8s - TTS WebSocket合成
┌──────────────────────────────────────┐
│ 1. TTS节点接收文本                    │
│ 2. 建立WebSocket连接                  │
│ 3. 发送文本: "呢杯咖啡系啡色嘅..."     │
│ 4. 流式接收音频数据                   │
└──────────────────────────────────────┘
           │
           ▼
T+4.8s - 音频播放
┌──────────────────────────────────────┐
│ 1. 播放合成语音                       │
│ 2. 持续约2-3秒                        │
│ 3. 播放完成，返回监听模式             │
└──────────────────────────────────────┘

总延迟: ~5秒 (从用户说完到系统开始回复)
```

### 4.2 ROS2消息流追踪

```bash
# 监控所有ROS2话题
ros2 topic list

# 输出:
/camera/image_raw          # 摄像头图像
/voice_command             # ASR识别结果
/vision/query              # 视觉查询
/vision/response           # 视觉响应
/llm_request               # LLM请求
/llm_response              # LLM响应
/tts_request               # TTS请求
/system_status             # 系统状态

# 实时监控特定话题
ros2 topic echo /voice_command    # 查看语音命令
ros2 topic echo /vision/response  # 查看视觉响应
ros2 topic echo /system_status    # 查看系统状态

# 查看消息频率
ros2 topic hz /camera/image_raw   # 应该是 ~30Hz (30fps)
```

---

## 5. 故障排查

### 5.1 WebSocket连接问题

```bash
# 问题1: ASR WebSocket连接失败
症状: 日志显示 "WebSocket connection failed"

排查:
1. 检查Token是否有效
   python3.10 -c "
   from aliyun_nls_token_manager import get_valid_token
   print(get_valid_token())
   "

2. 检查网络连接
   ping nls-gateway.cn-shanghai.aliyuncs.com

3. 检查SDK安装
   pip3.10 list | grep aliyun

4. 查看详细错误日志
   grep "WebSocket" ~/xlerobot/logs/*.log
```

### 5.2 视觉服务问题

```bash
# 问题2: 摄像头无图像
症状: /camera/image_raw 无消息发布

排查:
1. 检查摄像头设备
   ls /dev/video*
   v4l2-ctl --list-devices

2. 检查ROS2节点
   ros2 node list | grep camera

3. 测试摄像头
   v4l2-ctl --device=/dev/video0 --stream-mmap --stream-count=1

4. 重启摄像头节点
   ros2 run v4l2_camera v4l2_camera_node
```

### 5.3 多模态查询失败

```bash
# 问题3: Qwen-VL API调用失败
症状: 视觉查询返回错误

排查:
1. 检查API密钥
   echo $QWEN_API_KEY

2. 测试API连接
   curl -X POST https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions \
     -H "Authorization: Bearer $QWEN_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"model":"qwen-plus","messages":[{"role":"user","content":"你好"}]}'

3. 检查图像编码
   python3.10 -c "
   import base64
   with open('test.jpg', 'rb') as f:
       encoded = base64.b64encode(f.read())
       print(f'Image size: {len(encoded)} bytes')
   "

4. 查看详细错误
   grep "Qwen-VL" ~/xlerobot/logs/*.log
```

---

## 6. 性能指标

### 6.1 WebSocket性能

| 指标 | 目标值 | 实际值 | 说明 |
|------|--------|--------|------|
| ASR连接建立时间 | < 500ms | ~300ms | 首次连接 |
| ASR流式延迟 | < 200ms | ~150ms | 实时识别延迟 |
| TTS连接建立时间 | < 500ms | ~300ms | 首次连接 |
| TTS流式延迟 | < 300ms | ~200ms | 首片音频返回 |
| WebSocket心跳间隔 | 30s | 30s | 保持连接活跃 |

### 6.2 视觉处理性能

| 指标 | 目标值 | 实际值 | 说明 |
|------|--------|--------|------|
| 摄像头帧率 | 30fps | 30fps | 1080p分辨率 |
| 图像捕获延迟 | < 50ms | ~33ms | 单帧获取时间 |
| Qwen-VL推理延迟 | < 3s | 2-3s | 图像理解时间 |
| 端到端视觉查询 | < 5s | 4-5s | 从问题到回复 |

### 6.3 多模态交互性能

| 场景 | 目标延迟 | 实际延迟 | 瓶颈 |
|------|---------|---------|------|
| 纯语音交互 | < 5s | 4-5s | LLM推理 |
| 语音+视觉交互 | < 8s | 6-8s | VL推理 |
| 连续对话 | < 3s | 2-3s | 上下文管理 |

---

## 7. 最佳实践

### 7.1 WebSocket连接管理

```python
# 最佳实践1: 连接池管理
class WebSocketPool:
    """WebSocket连接池"""

    def __init__(self, max_connections=5):
        self.max_connections = max_connections
        self.asr_pool = []
        self.tts_pool = []

    def get_asr_connection(self):
        """获取ASR连接"""
        if len(self.asr_pool) < self.max_connections:
            # 创建新连接
            conn = create_asr_websocket()
            self.asr_pool.append(conn)
            return conn
        else:
            # 复用现有连接
            return self.asr_pool[0]
```

### 7.2 视觉查询优化

```python
# 最佳实践2: 图像缓存
class ImageCache:
    """图像缓存管理"""

    def __init__(self, max_size=10):
        self.cache = {}
        self.max_size = max_size
        self.access_order = []

    def add(self, image_id, image_data):
        """添加图像到缓存"""
        if len(self.cache) >= self.max_size:
            # LRU淘汰
            oldest = self.access_order.pop(0)
            del self.cache[oldest]

        self.cache[image_id] = image_data
        self.access_order.append(image_id)
```

### 7.3 多模态上下文管理

```python
# 最佳实践3: 上下文窗口
class MultimodalContext:
    """多模态上下文管理"""

    def __init__(self, window_size=5):
        self.history = []
        self.window_size = window_size

    def add_turn(self, user_input, system_response, modality):
        """添加对话轮次"""
        self.history.append({
            "user": user_input,
            "assistant": system_response,
            "modality": modality,  # "voice", "vision", "multimodal"
            "timestamp": time.time()
        })

        # 维护窗口大小
        if len(self.history) > self.window_size:
            self.history.pop(0)
```

---

## 8. 参考资料

### 8.1 官方文档

- [阿里云NLS WebSocket SDK文档](https://help.aliyun.com/document_detail/120727.html)
- [Qwen-VL API文档](https://help.aliyun.com/zh/dashscope/developer-reference/qwen-vl-api)
- [ROS2 Humble文档](https://docs.ros.org/en/humble/index.html)

### 8.2 项目内部文档

- [ASR服务技术规格](./asr-service-technical-specification.md)
- [TTS服务技术规格](./tts-service-technical-specification.md)
- [阿里云NLS WebSocket连接指南](./aliyun-nls-websocket-connection-guide.md)
- [主系统架构文档](./xlerobot-system-architecture-dataflow.md)

---

**文档结束**
**最后更新**: 2025-11-16
**文档版本**: v1.0
