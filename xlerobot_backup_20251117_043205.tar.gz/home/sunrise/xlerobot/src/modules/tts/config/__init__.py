"""
配置管理模块
"""

from .tts_config import TTSConfig

__all__ = ['TTSConfig']
