"""
文本处理模块
"""

from .text_processor import TextProcessor

__all__ = ['TextProcessor']
