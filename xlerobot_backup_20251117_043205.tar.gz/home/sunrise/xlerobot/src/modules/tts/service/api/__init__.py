"""
TTS RESTful API模块

提供TTS服务的RESTful API接口。
"""

from .tts_api import TTSAPIServer
