"""
TTS WebSocket接口模块

提供WebSocket流式TTS服务接口。
"""

from .websocket_server import TTSWebSocketServer
