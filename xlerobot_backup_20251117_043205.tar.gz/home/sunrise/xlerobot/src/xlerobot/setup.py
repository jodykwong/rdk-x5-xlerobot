#!/usr/bin/env python3.10
# -*- coding: utf-8 -*-

from setuptools import setup

package_name = 'xlerobot'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='XLeRobot Team',
    maintainer_email='sunrise@xlerobot.com',
    description='XLeRobot语音助手核心节点包',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'asr_bridge_node = xlerobot.nodes.asr_bridge_node:main',
            'llm_service_node = xlerobot.nodes.llm_service_node:main',
            'tts_service_node = xlerobot.nodes.tts_service_node:main',
            'voice_assistant_coordinator = xlerobot.nodes.voice_assistant_coordinator:main',
        ],
    },
)