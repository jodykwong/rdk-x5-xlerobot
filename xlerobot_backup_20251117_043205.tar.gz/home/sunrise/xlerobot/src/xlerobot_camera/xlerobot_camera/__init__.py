# XleRobot IMX219 Camera Driver for ROS2
# Based on D-Robotics RDK X5 VIN interface

from .vin_camera_driver import VINCameraDriver

__all__ = ['VINCameraDriver']