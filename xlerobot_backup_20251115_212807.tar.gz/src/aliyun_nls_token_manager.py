#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿里云NLS Token自动管理器
负责Token的获取、缓存、自动刷新和过期处理
XleRobot Story 1.1 - 语音唤醒和基础识别
"""

import os
import json
import time
import threading
from datetime import datetime, timedelta
import logging
from pathlib import Path

try:
    import yaml
    from aliyunsdkcore.client import AcsClient
    from aliyunsdkcore.request import CommonRequest
except ImportError as e:
    print(f"❌ 缺少必要依赖: {e}")
    print("请运行: pip3 install aliyun-python-sdk-core==2.15.1 PyYAML")
    exit(1)

class AliyunNLSTokenManager:
    """阿里云NLS Token管理器"""

    def __init__(self, config_path=None):
        """
        初始化Token管理器

        Args:
            config_path (str): 配置文件路径，如果为None则自动查找
        """
        if config_path is None:
            # 智能查找配置文件
            candidates = [
                os.getenv("ALIYUN_CONFIG_PATH"),
                os.path.join(os.getcwd(), "config/aliyun_nls_config.yaml"),
                "/home/sunrise/xlerobot/config/aliyun_nls_config.yaml",
                os.path.join(os.path.dirname(__file__), "../config/aliyun_nls_config.yaml")
            ]
            config_path = None
            for path in candidates:
                if path and os.path.exists(path):
                    config_path = path
                    break

            if config_path is None:
                # 如果所有路径都不存在，使用默认路径并创建目录
                config_path = "/home/sunrise/xlerobot/config/aliyun_nls_config.yaml"
                config_dir = os.path.dirname(config_path)
                os.makedirs(config_dir, exist_ok=True)

        self.config_path = config_path
        self.config = self._load_config()
        self.cache_file = Path(self.config.get('authentication', {}).get('token', {}).get('cache', {}).get('cache_file', '/tmp/aliyun_nls_token.cache'))
        self.buffer_seconds = self.config.get('authentication', {}).get('token', {}).get('cache', {}).get('buffer_seconds', 300)

        # Token信息
        self.token = None
        self.expire_time = 0
        self.last_refresh_time = 0

        # 线程锁
        self._lock = threading.Lock()

        # 设置日志
        self._setup_logging()

        # 初始化时尝试加载缓存
        self._load_cached_token()

        # 启动自动刷新线程
        self._start_auto_refresh()

        self.logger.info("🔧 阿里云NLS Token管理器初始化完成")

    def _setup_logging(self):
        """设置日志"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('AliyunNLSTokenManager')

    def _load_config(self):
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.error(f"❌ 配置文件加载失败: {e}")
            raise

    def _get_aliyun_client(self):
        """获取阿里云客户端"""
        token_config = self.config.get('authentication', {}).get('token', {})
        access_key_id = token_config.get('access_key_id', '')
        access_key_secret = token_config.get('access_key_secret', '')
        region_id = token_config.get('region_id', 'cn-shanghai')

        if not access_key_id or not access_key_secret:
            raise ValueError("❌ AccessKey ID或Secret未配置")

        return AcsClient(access_key_id, access_key_secret, region_id)

    def _request_new_token(self):
        """请求新的Token"""
        try:
            client = self._get_aliyun_client()

            request = CommonRequest()
            request.set_method('POST')
            request.set_domain('nls-meta.cn-shanghai.aliyuncs.com')
            request.set_version('2019-02-28')
            request.set_action_name('CreateToken')

            response = client.do_action_with_exception(request)
            token_data = json.loads(response)

            if 'Token' in token_data and 'Id' in token_data['Token']:
                return {
                    'token': token_data['Token']['Id'],
                    'expire_time': token_data['Token']['ExpireTime'],
                    'request_time': int(time.time())
                }
            else:
                raise ValueError("❌ Token响应格式错误")

        except Exception as e:
            self.logger.error(f"❌ Token请求失败: {e}")
            raise

    def _save_cached_token(self, token_data):
        """保存Token到缓存文件"""
        try:
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(token_data, f, ensure_ascii=False, indent=2)
            self.logger.debug(f"✅ Token已缓存到: {self.cache_file}")
        except Exception as e:
            self.logger.warning(f"⚠️ Token缓存保存失败: {e}")

    def _load_cached_token(self):
        """从缓存文件加载Token"""
        try:
            if not self.cache_file.exists():
                self.logger.info("📝 缓存文件不存在，将创建新的Token")
                return

            with open(self.cache_file, 'r', encoding='utf-8') as f:
                token_data = json.load(f)

            current_time = int(time.time())
            expire_time = token_data.get('expire_time', 0)

            # 检查Token是否仍然有效（考虑缓冲时间）
            if current_time < (expire_time - self.buffer_seconds):
                self.token = token_data.get('token')
                self.expire_time = expire_time
                self.last_refresh_time = token_data.get('request_time', current_time)

                remaining_time = expire_time - current_time
                remaining_hours = remaining_time // 3600

                self.logger.info(f"✅ 从缓存加载Token成功，剩余有效时间: {remaining_hours}小时")
                return
            else:
                self.logger.info("⏰ 缓存的Token已过期，将重新获取")

        except Exception as e:
            self.logger.warning(f"⚠️ 缓存Token加载失败: {e}")

    def refresh_token(self, force=False):
        """
        刷新Token

        Args:
            force (bool): 是否强制刷新

        Returns:
            bool: 刷新是否成功
        """
        with self._lock:
            current_time = int(time.time())

            # 检查是否需要刷新
            if not force and self.token and current_time < (self.expire_time - self.buffer_seconds):
                remaining_time = self.expire_time - current_time
                remaining_hours = remaining_time // 3600
                self.logger.debug(f"🔄 Token仍然有效，剩余时间: {remaining_hours}小时，无需刷新")
                return True

            try:
                self.logger.info("🔄 正在刷新阿里云NLS Token...")
                token_data = self._request_new_token()

                self.token = token_data['token']
                self.expire_time = token_data['expire_time']
                self.last_refresh_time = token_data['request_time']

                # 保存到缓存
                self._save_cached_token(token_data)

                # 计算剩余时间
                remaining_time = self.expire_time - current_time
                remaining_hours = remaining_time // 3600

                self.logger.info(f"✅ Token刷新成功！新Token有效期: {remaining_hours}小时")
                return True

            except Exception as e:
                self.logger.error(f"❌ Token刷新失败: {e}")
                return False

    def get_token(self):
        """
        获取有效的Token

        Returns:
            str: 有效的Token，如果获取失败返回None
        """
        with self._lock:
            current_time = int(time.time())

            # 检查当前Token是否有效
            if self.token and current_time < (self.expire_time - self.buffer_seconds):
                return self.token

            # 尝试刷新Token
            if self.refresh_token():
                return self.token

            self.logger.error("❌ 无法获取有效的Token")
            return None

    def is_token_valid(self):
        """
        检查当前Token是否有效

        Returns:
            bool: Token是否有效
        """
        if not self.token:
            return False

        current_time = int(time.time())
        return current_time < (self.expire_time - self.buffer_seconds)

    def get_token_info(self):
        """
        获取Token信息

        Returns:
            dict: Token信息
        """
        current_time = int(time.time())
        remaining_time = max(0, self.expire_time - current_time) if self.expire_time else 0

        return {
            'token': self.token[:20] + "..." + self.token[-20:] if self.token else None,
            'expire_time': self.expire_time,
            'remaining_seconds': remaining_time,
            'remaining_hours': remaining_time // 3600,
            'last_refresh_time': self.last_refresh_time,
            'is_valid': self.is_token_valid(),
            'cache_file': str(self.cache_file)
        }

    def _auto_refresh_worker(self):
        """自动刷新工作线程"""
        self.logger.info("🔄 Token自动刷新线程已启动")

        while True:
            try:
                time.sleep(60)  # 每分钟检查一次

                if not self.is_token_valid():
                    self.logger.info("⏰ Token即将过期或已过期，开始自动刷新...")
                    self.refresh_token()
                else:
                    # 检查是否需要提前刷新
                    current_time = int(time.time())
                    time_until_refresh = self.expire_time - current_time - self.buffer_seconds

                    if time_until_refresh <= 0:
                        self.logger.info("⏰ 到达刷新缓冲时间，开始自动刷新...")
                        self.refresh_token()

            except Exception as e:
                self.logger.error(f"❌ 自动刷新异常: {e}")
                time.sleep(300)  # 出错时等待5分钟再重试

    def _start_auto_refresh(self):
        """启动自动刷新线程"""
        refresh_thread = threading.Thread(target=self._auto_refresh_worker, daemon=True)
        refresh_thread.start()

    def cleanup(self):
        """清理资源"""
        try:
            if self.cache_file.exists():
                self.cache_file.unlink()
                self.logger.info("🗑️ 缓存文件已清理")
        except Exception as e:
            self.logger.warning(f"⚠️ 缓存清理失败: {e}")

# 全局Token管理器实例
_token_manager = None

def get_token_manager():
    """获取全局Token管理器实例"""
    global _token_manager
    if _token_manager is None:
        _token_manager = AliyunNLSTokenManager()
    return _token_manager

def get_valid_token():
    """获取有效的Token（便捷函数）"""
    manager = get_token_manager()
    return manager.get_token()

if __name__ == "__main__":
    # 测试Token管理器
    print("🚀 阿里云NLS Token管理器测试")
    print("=" * 50)

    try:
        manager = AliyunNLSTokenManager()

        # 显示Token信息
        token_info = manager.get_token_info()
        print(f"📋 Token信息:")
        print(f"  Token: {token_info['token']}")
        print(f"  剩余时间: {token_info['remaining_hours']} 小时")
        print(f"  是否有效: {token_info['is_valid']}")
        print(f"  缓存文件: {token_info['cache_file']}")

        # 测试获取Token
        print(f"\n🔑 获取Token测试:")
        token = manager.get_token()
        if token:
            print(f"✅ Token获取成功: {token[:20]}...{token[-20:]}")
        else:
            print("❌ Token获取失败")

        print(f"\n🎯 Token管理器运行中，按Ctrl+C退出...")

        # 保持运行，测试自动刷新
        try:
            while True:
                time.sleep(30)
                info = manager.get_token_info()
                print(f"⏰ Token状态 - 剩余: {info['remaining_hours']}h, 有效: {info['is_valid']}")
        except KeyboardInterrupt:
            print(f"\n👋 Token管理器已停止")

    except Exception as e:
        print(f"❌ Token管理器初始化失败: {e}")