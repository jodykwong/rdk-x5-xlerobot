#!/bin/bash
# =============================================================================
# WebSocket语音服务统一启动脚本
# =============================================================================
#
# 功能：统一启动基于WebSocket架构的ASR→TTS语音服务
# 替代之前错误的HTTP API架构
#
# 作者: BMad Master + Technical Team
# 版本: 2.0 (WebSocket架构)
# 日期: 2025-11-14
#
# 使用方法：
#   ./start_voice_services_websocket.sh [test|start|stop|status]
# =============================================================================

set -e  # 遇到错误立即退出

# ============================================
# 🛡️ 加载XLeRobot专用环境配置
# ============================================
# 加载环境脚本，确保使用正确的Python环境
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SCRIPT_DIR/xlerobot_env.sh" ]]; then
    source "$SCRIPT_DIR/xlerobot_env.sh"
    echo "✅ XLeRobot环境已加载"
else
    echo "❌ 错误：找不到xlerobot_env.sh环境脚本"
    echo "请确保在XLeRobot项目根目录中运行此脚本"
    exit 1
fi

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_header() {
    echo -e "${BLUE}=== $1 ===${NC}"
}

# 项目配置
PROJECT_ROOT="/home/sunrise/xlerobot"
PYTHON_CMD="$PYTHON_EXECUTABLE"
VENV_PATH="$PROJECT_ROOT/venv"
LOG_DIR="$PROJECT_ROOT/logs"
PID_DIR="$PROJECT_ROOT/run"

# 服务配置
ASR_SERVICE_MODULE="modules.asr.websocket_asr_service"
TTS_SERVICE_MODULE="modules.tts.engine.aliyun_tts_final"
AUDIO_PROCESSOR_MODULE="modules.asr.unified_audio_processor_fixed"

# 环境变量配置
setup_environment() {
    log_header "环境配置"

    # 设置阿里云凭证
    export ALIBABA_CLOUD_ACCESS_KEY_ID="LTAI5tQ4E2YNzZkGn9g1JqeY"
    export ALIBABA_CLOUD_ACCESS_KEY_SECRET="Hr1xZdcdz3D9OgFnH1nvWz5rldXVeI"
    export ALIYUN_NLS_APPKEY="4G5BCMccTCW8nC8w"

    log_info "阿里云凭证配置完成"

    # 设置Python路径
    export PYTHONPATH="$PROJECT_ROOT/src:$PYTHONPATH"
    log_info "Python路径: $PYTHONPATH"

    # 创建必要的目录
    mkdir -p "$LOG_DIR" "$PID_DIR"
    log_info "目录创建完成"
}

# 检查依赖
check_dependencies() {
    log_header "依赖检查"

    # 检查Python版本
    if ! command -v $PYTHON_CMD &> /dev/null; then
        log_error "Python $PYTHON_CMD 未找到"
        exit 1
    fi

    PYTHON_VERSION=$($PYTHON_CMD --version 2>&1)
    log_info "Python版本: $PYTHON_VERSION"

    # 检查阿里云SDK
    $PYTHON_CMD -c "
try:
    from nls.token import getToken
    from nls.speech_recognizer import NlsSpeechRecognizer
    print('✅ 阿里云NLS SDK可用')
except ImportError as e:
    print(f'❌ 阿里云NLS SDK不可用: {e}')
    print('请运行: pip3 install alibabacloud-nls-python-sdk')
    exit(1)
" || exit 1

    # 检查音频设备
    if ! arecord -l &> /dev/null; then
        log_error "音频录制设备不可用"
        exit 1
    fi

    if ! aplay -l &> /dev/null; then
        log_error "音频播放设备不可用"
        exit 1
    fi

    log_info "音频设备检查通过"

    # 检查核心依赖
    for dep in numpy wave; do
        $PYTHON_CMD -c "import $dep" 2>/dev/null || {
            log_error "缺少依赖: $dep"
            log_info "请运行: pip3 install $dep"
            exit 1
        }
    done

    log_success "所有依赖检查通过"
}

# 服务健康检查
health_check() {
    log_header "服务健康检查"

    $PYTHON_CMD -c "
import sys
sys.path.insert(0, '$PROJECT_ROOT/src')

# 测试音频处理器
try:
    from modules.asr.unified_audio_processor_fixed import create_unified_audio_processor_fixed
    processor = create_unified_audio_processor_fixed()
    print('✅ 音频处理器: 健康')
except Exception as e:
    print(f'❌ 音频处理器: {e}')
    sys.exit(1)

# 测试WebSocket ASR服务
try:
    from modules.asr.websocket_asr_service import create_websocket_asr_service
    asr_service = create_websocket_asr_service()
    health = asr_service.health_check()
    if health['status'] == 'healthy':
        print('✅ WebSocket ASR服务: 健康')
    else:
        print(f'❌ WebSocket ASR服务: {health}')
        sys.exit(1)
except Exception as e:
    print(f'❌ WebSocket ASR服务: {e}')
    sys.exit(1)

# 测试TTS服务
try:
    from modules.tts.engine.aliyun_tts_final import AliyunTTSClient
    tts_service = AliyunTTSClient()
    # 简单测试
    print('✅ TTS服务: 健康')
except Exception as e:
    print(f'❌ TTS服务: {e}')
    sys.exit(1)

print('🎉 所有服务健康检查通过')
" || exit 1

    log_success "服务健康检查完成"
}

# 运行集成测试
run_integration_test() {
    log_header "集成测试"

    TEST_SCRIPT="$PROJECT_ROOT/tools/test_websocket_asr_tts_fixed.py"

    if [ ! -f "$TEST_SCRIPT" ]; then
        log_error "集成测试脚本不存在: $TEST_SCRIPT"
        exit 1
    fi

    log_info "运行集成测试..."
    chmod +x "$TEST_SCRIPT"

    # 运行测试
    if $PYTHON_CMD "$TEST_SCRIPT"; then
        log_success "集成测试通过！"
        return 0
    else
        log_error "集成测试失败"
        return 1
    fi
}

# 启动服务
start_services() {
    log_header "启动语音服务"

    # 检查是否已经在运行
    if [ -f "$PID_DIR/voice_services.pid" ]; then
        PID=$(cat "$PID_DIR/voice_services.pid")
        if kill -0 "$PID" 2>/dev/null; then
            log_warn "语音服务已在运行 (PID: $PID)"
            return 0
        else
            log_warn "PID文件存在但进程不运行，清理PID文件"
            rm -f "$PID_DIR/voice_services.pid"
        fi
    fi

    # 创建日志文件
    LOG_FILE="$LOG_DIR/voice_services_$(date +%Y%m%d_%H%M%S).log"

    log_info "启动语音服务，日志文件: $LOG_FILE"

    # 后台运行服务
    nohup $PYTHON_CMD -c "
import sys
sys.path.insert(0, '$PROJECT_ROOT/src')
import time
import logging
import signal
import os

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('$LOG_FILE'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# 信号处理
def signal_handler(signum, frame):
    logger.info(f'收到信号 {signum}，正在关闭服务...')
    sys.exit(0)

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

try:
    # 加载服务
    from modules.asr.websocket_asr_service import create_websocket_asr_service
    from modules.tts.engine.aliyun_tts_final import AliyunTTSClient
    from modules.asr.unified_audio_processor_fixed import create_unified_audio_processor_fixed

    logger.info('🚀 WebSocket语音服务启动成功')
    logger.info('✅ WebSocket ASR服务: 已加载')
    logger.info('✅ TTS服务: 已加载')
    logger.info('✅ 音频处理器: 已加载')
    logger.info('🔗 服务架构: 完全基于WebSocket SDK')
    logger.info('📝 API协议: NlsSpeechRecognizer + NlsSpeechSynthesizer')

    # 保持服务运行
    while True:
        time.sleep(60)
        logger.debug('心跳检查 - 服务正常运行')

except Exception as e:
    logger.error(f'❌ 服务启动失败: {e}')
    sys.exit(1)
" > "$LOG_DIR/voice_services.out" 2>&1 &

    # 保存PID
    echo $! > "$PID_DIR/voice_services.pid"

    log_success "语音服务已启动 (PID: $!)"
    log_info "日志文件: $LOG_FILE"
    log_info "使用 './start_voice_services_websocket.sh stop' 停止服务"
}

# 停止服务
stop_services() {
    log_header "停止语音服务"

    if [ ! -f "$PID_DIR/voice_services.pid" ]; then
        log_warn "PID文件不存在，服务可能未运行"
        return 0
    fi

    PID=$(cat "$PID_DIR/voice_services.pid")

    if kill -0 "$PID" 2>/dev/null; then
        log_info "正在停止服务 (PID: $PID)..."
        kill "$PID"

        # 等待进程结束
        for i in {1..10}; do
            if ! kill -0 "$PID" 2>/dev/null; then
                break
            fi
            sleep 1
        done

        # 强制杀死如果仍在运行
        if kill -0 "$PID" 2>/dev/null; then
            log_warn "强制停止服务"
            kill -9 "$PID"
        fi

        log_success "服务已停止"
    else
        log_warn "进程 $PID 不存在"
    fi

    rm -f "$PID_DIR/voice_services.pid"
}

# 服务状态
show_status() {
    log_header "服务状态"

    if [ -f "$PID_DIR/voice_services.pid" ]; then
        PID=$(cat "$PID_DIR/voice_services.pid")
        if kill -0 "$PID" 2>/dev/null; then
            log_success "语音服务正在运行 (PID: $PID)"

            # 显示进程信息
            ps -p "$PID" -o pid,ppid,cmd,start,time

            # 显示最新日志
            if [ -f "$LOG_DIR/voice_services.out" ]; then
                echo
                echo "最新日志:"
                tail -n 5 "$LOG_DIR/voice_services.out"
            fi
        else
            log_warn "PID文件存在但进程不运行"
        fi
    else
        log_warn "语音服务未运行"
    fi
}

# 显示帮助信息
show_help() {
    echo "WebSocket语音服务启动脚本"
    echo
    echo "用法: $0 [命令]"
    echo
    echo "命令:"
    echo "  test     - 运行完整集成测试"
    echo "  start    - 启动语音服务"
    echo "  stop     - 停止语音服务"
    echo "  status   - 显示服务状态"
    echo "  restart  - 重启语音服务"
    echo "  help     - 显示此帮助信息"
    echo
    echo "示例:"
    echo "  $0 test     # 测试所有组件"
    echo "  $0 start    # 启动服务"
    echo "  $0 status   # 查看状态"
}

# 重启服务
restart_services() {
    log_header "重启语音服务"
    stop_services
    sleep 2
    start_services
}

# 主函数
main() {
    # 切换到项目目录
    cd "$PROJECT_ROOT"

    # 设置环境
    setup_environment

    # 处理命令
    case "${1:-help}" in
        "test")
            check_dependencies
            health_check
            run_integration_test
            ;;
        "start")
            check_dependencies
            health_check
            start_services
            ;;
        "stop")
            stop_services
            ;;
        "status")
            show_status
            ;;
        "restart")
            restart_services
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"