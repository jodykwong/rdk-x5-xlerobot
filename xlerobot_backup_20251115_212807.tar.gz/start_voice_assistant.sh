#!/bin/bash
# XleRobot Epic 1 快速启动脚本
# =============================
#
# 快速启动纯在线多模态交互服务
# 包含环境检查和错误处理
#
# 使用方法:
#   ./start_voice_assistant.sh    # 启动服务
#   ./start_voice_assistant.sh status  # 检查状态
#   ./start_voice_assistant.sh stop    # 停止服务

set -e

# ============================================
# 🛡️ 加载XLeRobot专用环境配置
# ============================================
# 加载环境脚本，确保使用正确的Python环境
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SCRIPT_DIR/xlerobot_env.sh" ]]; then
    source "$SCRIPT_DIR/xlerobot_env.sh"
    log_info "✅ XLeRobot环境已加载"
else
    echo "❌ 错误：找不到xlerobot_env.sh环境脚本"
    echo "请确保在XLeRobot项目根目录中运行此脚本"
    exit 1
fi

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 配置
PROJECT_ROOT="/home/sunrise/xlerobot"
PID_FILE="/tmp/xlerobot_voice_assistant.pid"
LOG_FILE="$PROJECT_ROOT/logs/voice_assistant.log"

# 创建日志目录
mkdir -p "$(dirname "$LOG_FILE")"

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

# 显示横幅
show_banner() {
    echo ""
    echo -e "${PURPLE}================================================================${NC}"
    echo -e "${CYAN}🤖 XleRobot Epic 1 多模态在线智能交互系统${NC}"
    echo -e "${PURPLE}================================================================${NC}"
    echo -e "${CYAN}🌐 架构: 多模态在线服务 (语音+视觉+对话)${NC}"
    echo -e "${CYAN}🎤 功能: ASR → LLM → TTS + Qwen-VL视觉理解${NC}"
    echo -e "${CYAN}🗣️ 特色: 粤语角色"傻强" + 智能视觉理解${NC}"
    echo -e "${CYAN}📷 支持: Qwen3-VL-Plus多模态大模型${NC}"
    echo -e "${PURPLE}================================================================${NC}"
    echo ""
}

# 显示帮助信息
show_help() {
    cat << EOF
XleRobot Epic 1 语音助手启动脚本

用法: $0 [命令] [选项]

命令:
    (无参数)        启动语音助手服务（包含完整环境检查）
    --force         强制启动（跳过环境检查）
    status          检查服务运行状态
    stop            停止服务
    restart         重启服务
    logs            查看服务日志
    check           仅执行环境检查
    help            显示此帮助信息

环境检查功能:
    ✅ Python环境验证
    ✅ 项目结构完整性检查
    ✅ Epic 1多模态功能模块检查:
       🌐 核心模块(ASR/LLM/TTS)
       👁️ 视觉理解模块(Qwen-VL)
       💬 在线对话服务模块
       🧠 智能控制模块
       🧪 Epic 1测试套件
    ✅ 多模态Python依赖检查:
       💻 核心依赖(asyncio/requests等)
       👁️ 视觉处理模块(OpenCV/PIL/NumPy/PyTorch)
       🤖 ROS2多模态模块(rclpy/sensor_msgs/cv_bridge)
    ✅ 摄像头设备检查(/dev/video* + 摄像头工具)
    ✅ 分层API服务连接测试:
       🎤 ASR语音识别服务端点(nls-gateway, nls-meta)
       🔊 TTS语音合成服务端点(阿里云TTS)
       🧠 LLM大语言模型服务端点(dashscope)
       👁️ 视觉理解服务端点(Qwen-VL多模态API)
    ✅ 多模态环境变量检查(包含QWEN_API_KEY)
    ✅ 音频设备检查(录音+播放)
    ✅ 系统资源评估(内存/CPU/磁盘)
    ✅ 权限验证
    ✅ 多模态服务端口检查

示例:
    $0                  # 启动服务（完整检查）
    $0 --force          # 强制启动（跳过检查）
    $0 status           # 查看状态
    $0 check            # 仅环境检查
    $0 logs             # 查看日志

故障排除:
    如果环境检查失败，请根据提示进行修复：
    1. 安装依赖: pip3.10 install -r requirements.txt
    2. 设置环境变量: export ALIBABA_CLOUD_ACCESS_KEY_ID='your_key'
    3. 检查音频: sudo apt-get install alsa-utils pulseaudio
    4. 强制启动: $0 --force

EOF
}

# 环境检查
check_environment() {
    log_info "🔧 执行全面环境检查..."
    local errors=0
    local warnings=0

    echo -e "${CYAN}📋 环境检查报告${NC}"
    echo "=================================="

    # 第一阶段：硬件设备检查
    log_info "🎯 第一阶段：硬件设备检查"
    echo "----------------------------------"

    # 1. 音频设备检查（优先级最高）
    log_info "🎤 检查音频设备..."
    local audio_devices_ok=true

    # 检查录音设备
    if arecord -l &> /dev/null; then
        local input_devices=$(arecord -l | grep -c "card [0-9]*:")
        log_success "✅ 录音设备: 找到 $input_devices 个设备"
        if [ "$input_devices" -gt 0 ]; then
            echo "   录音设备列表:"
            arecord -l | grep "card [0-9]*:" | sed 's/^/     /'
        fi
    else
        log_error "❌ 无录音设备或arecord不可用"
        audio_devices_ok=false
        ((errors++))
    fi

    # 检查播放设备
    if aplay -l &> /dev/null; then
        local output_devices=$(aplay -l | grep -c "card [0-9]*:")
        log_success "✅ 播放设备: 找到 $output_devices 个设备"
        if [ "$output_devices" -gt 0 ]; then
            echo "   播放设备列表:"
            aplay -l | grep "card [0-9]*:" | sed 's/^/     /'
        fi
    else
        log_error "❌ 无播放设备或aplay不可用"
        audio_devices_ok=false
        ((errors++))
    fi

    # 2. 摄像头设备检查
    log_info "📷 检查摄像头设备和驱动..."

    # 检查视频驱动模块加载状态
    log_info "   检查视频驱动模块:"
    local driver_modules=("uvcvideo" "videobuf2_vmalloc" "videobuf2_memops" "videobuf2_v4l2" "videobuf2_common")
    local loaded_drivers=0

    for module in "${driver_modules[@]}"; do
        if lsmod | grep -q "^$module "; then
            log_success "   ✅ 驱动模块: $module"
            ((loaded_drivers++))
        else
            log_info "   ❌ 未加载: $module"
        fi
    done

    # 检查摄像头设备文件
    log_info "   检查摄像头设备节点:"
    local camera_devices=0
    local camera_device_list=""

    for i in {0..9}; do
        local device_path="/dev/video$i"
        if [ -e "$device_path" ]; then
            ((camera_devices++))
            camera_device_list="$camera_device_list $device_path"
            log_success "   ✅ 设备节点: $device_path"

            # 检查设备权限
            if [ -r "$device_path" ] && [ -w "$device_path" ]; then
                log_info "      权限: 可读写 ✅"
            else
                log_warning "      权限: 需要修复 ⚠️"
                log_info "      修复: sudo usermod -a -G video $USER && sudo chmod 666 $device_path"
                ((warnings++))
            fi
        fi
    done

    if [ $camera_devices -gt 0 ]; then
        log_success "✅ 找到 $camera_devices 个摄像头设备: $camera_device_list"
    else
        log_warning "⚠️ 未找到摄像头设备节点"
        log_info "   多模态服务需要摄像头进行视觉理解"
        ((warnings++))
    fi

    # 3. 系统资源检查
    log_info "💻 检查系统资源..."

    # 内存检查
    local total_memory=$(free -m | awk 'NR==2{print $2}')
    local available_memory=$(free -m | awk 'NR==2{print $7}')
    local memory_usage=$(( (total_memory - available_memory) * 100 / total_memory ))

    log_info "   内存: ${available_memory}MB可用 / ${total_memory}MB总计 (${memory_usage}%)"
    if [ "$available_memory" -lt 1000 ]; then
        log_warning "⚠️ 可用内存不足1GB，可能影响性能"
        ((warnings++))
    else
        log_success "✅ 内存充足"
    fi

    # CPU检查
    local cpu_cores=$(nproc)
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | tr -d ',')
    log_info "   CPU: $cpu_cores 核心，负载: $cpu_load"

    # 磁盘空间检查
    local disk_available=$(df -m "$PROJECT_ROOT" | awk 'NR==2{print $4}')
    if [ "$disk_available" -lt 1000 ]; then
        log_warning "⚠️ 磁盘空间不足: ${disk_available}MB"
        ((warnings++))
    else
        log_success "✅ 磁盘空间充足: ${disk_available}MB"
    fi

    # 第二阶段：运行环境检查
    echo ""
    log_info "🌐 第二阶段：运行环境检查"
    echo "----------------------------------"

    # 4. Python环境检查
    log_info "🐍 检查Python环境..."
    if command -v $PYTHON_EXECUTABLE &> /dev/null; then
        local python_version=$($PYTHON_EXECUTABLE --version 2>&1)
        log_success "✅ Python: $python_version"

        # 检查当前使用的python3是否指向conda
        local current_python3=$(which python3 2>/dev/null || echo "未配置")
        if [[ "$current_python3" == *"conda"* ]] || [[ "$current_python3" == *"miniconda"* ]]; then
            log_error "❌ 检测到conda Python环境冲突！"
            log_error "   当前python3: $current_python3"
            log_error "   XLeRobot必须使用系统Python 3.10，不能使用conda环境"
            log_info "   解决方案:"
            log_info "   1. 运行: source ./xlerobot_env.sh"
            log_info "   2. 或者重新启动shell使配置生效"
            ((errors++))
        else
            log_success "✅ Python环境检查通过，当前python3: $current_python3"
        fi
    else
        log_error "❌ Python3.10 未找到"
        log_info "   请安装Python3.10或设置正确的PATH"
        ((errors++))
    fi

    # 4.1. Miniconda/Conda冲突检测
    log_info "🛡️ 检查conda/miniconda冲突..."

    # 检查PATH中的conda路径
    if echo "$PATH" | grep -q "conda\|miniconda"; then
        log_warning "⚠️  PATH中检测到conda/miniconda路径"
        log_warning "   这可能导致Python环境冲突"
        echo "   以下路径将被清理:"
        echo "$PATH" | tr ':' '\n' | grep -E "conda|miniconda" | sed 's/^/     /'
    else
        log_success "✅ PATH未包含conda/miniconda路径"
    fi

    # 检查活跃的conda环境
    if [[ -n "$CONDA_DEFAULT_ENV" ]]; then
        log_error "❌ 检测到活跃的conda环境: $CONDA_DEFAULT_ENV"
        log_error "   XLeRobot不能在conda环境中运行"
        log_info "   请运行: conda deactivate"
        ((errors++))
    else
        log_success "✅ 未检测到活跃的conda环境"
    fi

    # 5. 项目目录检查
    log_info "📁 检查项目结构..."
    if [ ! -d "$PROJECT_ROOT" ]; then
        log_error "❌ 项目目录不存在: $PROJECT_ROOT"
        ((errors++))
    else
        log_success "✅ 项目目录: $PROJECT_ROOT"

        # 检查关键目录
        local required_dirs=("src" "src/modules" "src/modules/asr" "src/modules/tts" "src/modules/llm")
        for dir in "${required_dirs[@]}"; do
            if [ -d "$PROJECT_ROOT/$dir" ]; then
                log_success "✅ 目录: $dir"
            else
                log_error "❌ 缺少目录: $dir"
                ((errors++))
            fi
        done
    fi

    # 6. ROS2环境检查（多模态系统必需）
    log_info "🤖 检查ROS2环境..."
    local ros2_ok=true

    # 检查ROS2命令
    if command -v ros2 &> /dev/null; then
        local ros2_version=$(ros2 --version 2>&1)
        log_success "✅ ROS2命令: $ros2_version"
    else
        log_error "❌ ROS2命令未找到"
        log_info "   请安装ROS2: sudo apt install ros-humble-desktop"
        ros2_ok=false
        ((errors++))
    fi

    # 检查ROS2环境变量
    if [ -n "$ROS_DISTRO" ]; then
        log_success "✅ ROS发行版: $ROS_DISTRO"
    else
        log_warning "⚠️ ROS_DISTRO环境变量未设置"
        log_info "   请执行: source /opt/ros/humble/setup.bash"
        ((warnings++))
    fi

    # 检查ROS_DOMAIN_ID
    if [ -n "$ROS_DOMAIN_ID" ]; then
        log_success "✅ ROS_DOMAIN_ID: $ROS_DOMAIN_ID"
    else
        log_warning "⚠️ ROS_DOMAIN_ID未设置，使用默认值"
        log_info "   建议设置: export ROS_DOMAIN_ID=42"
        ((warnings++))
    fi

    # 检查ROS2节点编译状态
    log_info "   检查ROS2包编译状态..."
    if [ -f "install/setup.bash" ]; then
        log_success "✅ ROS2包已编译"

        # 检查关键包
        local key_packages=(
            "xlerobot:XLeRobot核心节点"
            "audio_msg:音频消息定义"
        )

        for package_info in "${key_packages[@]}"; do
            local package=$(echo "$package_info" | cut -d':' -f1)
            local desc=$(echo "$package_info" | cut -d':' -f2-)

            if [ -d "install/$package" ]; then
                log_success "✅ $desc 已编译"
            else
                log_warning "⚠️ $desc 未编译"
                log_info "   编译: colcon build --packages-select $package"
                ((warnings++))
            fi
        done
    else
        log_error "❌ ROS2包未编译"
        log_info "   编译: colcon build --packages-select xlerobot audio_msg"
        ((errors++))
    fi

    # 检查ROS2 Python模块
    log_info "   检查ROS2 Python模块..."
    local ros_modules=(
        "rclpy:ROS2 Python客户端"
        "sensor_msgs:传感器消息"
        "cv_bridge:CV桥接器"
        "geometry_msgs:几何消息"
        "std_msgs:标准消息"
        "nav_msgs:导航消息"
        "audio_msg:自定义音频消息"
    )

    for module_info in "${ros_modules[@]}"; do
        local module=$(echo "$module_info" | cut -d':' -f1)
        local desc=$(echo "$module_info" | cut -d':' -f2-)

        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ ROS模块: $desc"
        else
            log_warning "⚠️ 缺少ROS模块: $desc"
            log_info "   安装: sudo apt install ros-humble-$module"
            ((warnings++))
        fi
    done

    # 7. 多模态依赖库检查
    log_info "👁️ 检查多模态Python依赖..."
    local multimodal_modules=(
        "cv2:OpenCV视觉处理"
        "PIL:PIL图像处理"
        "numpy:数值计算库"
        "matplotlib:图像显示"
        "torch:PyTorch深度学习"
        "torchvision:视觉模型库"
        "scipy:科学计算库"
    )

    for module_info in "${multimodal_modules[@]}"; do
        local module=$(echo "$module_info" | cut -d':' -f1)
        local desc=$(echo "$module_info" | cut -d':' -f2-)

        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ 多模态模块: $desc"
        else
            log_warning "⚠️ 缺少多模态模块: $desc - 视觉功能受限"
            ((warnings++))
        fi
    done

    # 8. 核心Python依赖检查
    log_info "📦 检查核心Python依赖..."
    local critical_modules=(
        "asyncio:异步IO"
        "threading:多线程"
        "queue:队列管理"
        "requests:HTTP客户端"
        "aiohttp:异步HTTP"
        "base64:编码解码"
        "json:JSON处理"
        "logging:日志系统"
        "time:时间模块"
        "os:操作系统接口"
        "sys:系统相关"
        "pathlib:路径处理"
        "signal:信号处理"
        "subprocess:子进程管理"
    )

    for module_info in "${critical_modules[@]}"; do
        local module=$(echo "$module_info" | cut -d':' -f1)
        local desc=$(echo "$module_info" | cut -d':' -f2-)

        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ 核心模块: $desc"
        else
            log_error "❌ 缺少核心模块: $desc"
            ((errors++))
        fi
    done

    # 第三阶段：配置和服务检查
    echo ""
    log_info "⚙️ 第三阶段：配置和服务检查"
    echo "----------------------------------"

    # 6. Epic 1多模态功能检查
    log_info "🌐 检查Epic 1多模态功能模块..."

    # 核心ASR/LLM/TTS模块
    local core_files=(
        "start_epic1_services.py:主启动服务"
        "src/modules/asr/simple_aliyun_asr_service.py:ASR服务"
        "src/modules/llm/qwen_client.py:LLM客户端"
        "src/modules/tts/engine/aliyun_tts_final.py:TTS引擎"
    )

    for file_info in "${core_files[@]}"; do
        local file=$(echo "$file_info" | cut -d':' -f1)
        local desc=$(echo "$file_info" | cut -d':' -f2-)
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "✅ $desc: $file"
        else
            log_error "❌ 缺少核心文件: $file"
            ((errors++))
        fi
    done

    # Epic 1多模态视觉模块检查
    log_info "   👁️ 视觉理解模块:"
    local vision_files=(
        "src/xlerobot_vision/xlerobot_vision/qwen_vl_client.py:Qwen-VL视觉客户端"
        "src/xlerobot_vision/vision_llm_node.py:视觉LLM节点"
        "src/xlerobot_vision/multimodal_context.py:多模态上下文管理"
        "src/xlerobot_vision/integration_test.py:多模态集成测试"
    )

    for file_info in "${vision_files[@]}"; do
        local file=$(echo "$file_info" | cut -d':' -f1)
        local desc=$(echo "$file_info" | cut -d':' -f2-)
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "✅ $desc"
        else
            log_warning "⚠️ 缺少视觉模块: $desc - 多模态功能受限"
            ((warnings++))
        fi
    done

    # Epic 1在线对话模块检查
    log_info "   💬 在线对话服务模块:"
    local dialogue_files=(
        "src/xlerobot_online_dialogue/xlerobot_online_dialogue/online_dialogue_api.py:在线对话API"
        "src/xlerobot_online_dialogue/launch/online_dialogue.launch.py:对话服务启动"
        "src/xlerobot_online_dialogue/config/online_dialogue_config.yaml:对话服务配置"
    )

    for file_info in "${dialogue_files[@]}"; do
        local file=$(echo "$file_info" | cut -d':' -f1)
        local desc=$(echo "$file_info" | cut -d':' -f2-)
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "✅ $desc"
        else
            log_warning "⚠️ 缺少对话模块: $desc - 在线对话功能受限"
            ((warnings++))
        fi
    done

    # Epic 1智能模块检查
    log_info "   🧠 智能控制模块:"
    local smart_files=(
        "src/modules/smart_home/iot_service_node.py:智能家居集成"
        "src/modules/system_control/architecture.py:系统架构管理"
        "src/integration/real_voice_assistant.py:真实语音助手"
    )

    for file_info in "${smart_files[@]}"; do
        local file=$(echo "$file_info" | cut -d':' -f1)
        local desc=$(echo "$file_info" | cut -d':' -f2-)
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "✅ $desc"
        else
            log_info "ℹ️ 可选模块: $desc"
        fi
    done

    # Epic 1测试套件检查
    log_info "   🧪 Epic 1测试套件:"
    local test_files=(
        "tests/test_audio_components.py:音频组件测试"
        "tests/test_aliyun_api_integration.py:阿里云API集成测试"
        "tests/test_e2e_integration.py:端到端集成测试"
        "tests/test_runner.py:测试运行器"
    )

    for file_info in "${test_files[@]}"; do
        local file=$(echo "$file_info" | cut -d':' -f1)
        local desc=$(echo "$file_info" | cut -d':' -f2-)
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "✅ $desc"
        else
            log_warning "⚠️ 缺少测试模块: $desc - 质量保证受限"
            ((warnings++))
        fi
    done

    # 4. Python依赖检查
    log_info "📦 检查多模态Python依赖..."
    local critical_modules=(
        "asyncio"
        "threading"
        "queue"
        "requests"
        "aiohttp"
        "base64"
        "json"
        "logging"
        "time"
    )

    for module in "${critical_modules[@]}"; do
        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ 核心模块: $module"
        else
            log_error "❌ 缺少核心模块: $module"
            ((errors++))
        fi
    done

    # 检查视觉处理模块
    log_info "👁️ 检查视觉处理Python模块..."
    local vision_modules=(
        "cv2:OpenCV视觉处理"
        "PIL:PIL图像处理"
        "numpy:数值计算库"
        "matplotlib:图像显示"
        "torch:PyTorch深度学习"
    )

    for module_info in "${vision_modules[@]}"; do
        local module=$(echo "$module_info" | cut -d':' -f1)
        local desc=$(echo "$module_info" | cut -d':' -f2-)

        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ 视觉模块: $desc"
        else
            log_warning "⚠️ 缺少视觉模块: $desc - 视觉功能受限"
            ((warnings++))
        fi
    done

    # 检查ROS2视觉模块
    log_info "🤖 检查ROS2多模态模块..."
    local ros_modules=(
        "rclpy:ROS2 Python客户端"
        "sensor_msgs:传感器消息"
        "cv_bridge:CV桥接器"
        "geometry_msgs:几何消息"
    )

    for module_info in "${ros_modules[@]}"; do
        local module=$(echo "$module_info" | cut -d':' -f1)
        local desc=$(echo "$module_info" | cut -d':' -f2-)

        if $PYTHON_EXECUTABLE -c "import $module" 2>/dev/null; then
            log_success "✅ ROS模块: $desc"
        else
            log_warning "⚠️ 缺少ROS模块: $desc - 集成功能受限"
            ((warnings++))
        fi
    done

    # 5. 摄像头设备检查（多模态服务必需）
    log_info "📷 检查摄像头设备和驱动..."

    # 检查视频驱动模块加载状态
    log_info "   检查视频驱动模块:"
    local driver_modules=("uvcvideo" "videobuf2_vmalloc" "videobuf2_memops" "videobuf2_v4l2" "videobuf2_common")
    local loaded_drivers=0

    for module in "${driver_modules[@]}"; do
        if lsmod | grep -q "^$module "; then
            log_success "   ✅ 驱动模块: $module"
            ((loaded_drivers++))
        else
            log_info "   ❌ 未加载: $module"
        fi
    done

    # 检查摄像头设备文件
    log_info "   检查摄像头设备节点:"
    local camera_devices=0
    local camera_device_list=""

    for i in {0..9}; do
        local device_path="/dev/video$i"
        if [ -e "$device_path" ]; then
            ((camera_devices++))
            camera_device_list="$camera_device_list $device_path"
            log_success "   ✅ 设备节点: $device_path"

            # 检查设备权限
            if [ -r "$device_path" ] && [ -w "$device_path" ]; then
                log_info "      权限: 可读写 ✅"
            else
                log_warning "      权限: 需要修复 ⚠️"
                log_info "      修复: sudo usermod -a -G video $USER && sudo chmod 666 $device_path"
                ((warnings++))
            fi
        fi
    done

    if [ $camera_devices -gt 0 ]; then
        log_success "✅ 找到 $camera_devices 个摄像头设备: $camera_device_list"

        # 尝试获取摄像头详细信息
        if command -v v4l2-ctl &> /dev/null; then
            log_info "   摄像设备详细信息:"
            v4l2-ctl --list-devices 2>/dev/null | while read -r line; do
                echo "      $line"
                # 只显示前10行详细信息
                if [ "$(echo "$line" | grep -c "device")" -eq 2 ]; then
                    break
                fi
            done || true

            # 检查摄像头支持的格式
            log_info "   检查支持的视频格式:"
            if [ -e "/dev/video0" ]; then
                v4l2-ctl -d /dev/video0 --list-formats 2>/dev/null | head -5 | while read -r line; do
                    echo "      $line"
                done || log_info "      无法获取格式信息"
            fi
        fi
    else
        log_warning "⚠️ 未找到摄像头设备节点"
        log_info "   多模态服务需要摄像头进行视觉理解"
        ((warnings++))

        # 诊断建议
        log_info "   诊断建议:"
        log_info "   1. 检查摄像头硬件连接"
        log_info "   2. 尝试重新插拔USB摄像头"
        log_info "   3. 检查系统日志: dmesg | grep -i video"
        log_info "   4. 尝试加载驱动: sudo modprobe uvcvideo"
    fi

    # 检查摄像头工具
    log_info "   检查摄像头管理工具:"
    local camera_tools=("fswebcam" "ffmpeg" "v4l2-ctl" "cheese" "guvcview")
    local available_tools=0
    local tool_info=""

    for tool in "${camera_tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            ((available_tools++))
            tool_info="$tool_info $tool"
            log_success "   ✅ 可用工具: $tool"
        fi
    done

    if [ $available_tools -eq 0 ]; then
        log_warning "⚠️ 未找到摄像头管理工具"
        log_info "   安装建议:"
        log_info "   sudo apt-get install v4l-utils fswebcam cheese"
        ((warnings++))
    else
        log_success "✅ 摄像头工具套件: $tool_info"
    fi

    # 检查摄像头权限组
    if ! groups | grep -q "video"; then
        log_warning "⚠️ 用户不在video组中"
        log_info "   修复命令: sudo usermod -a -G video $USER"
        log_info "   然后重新登录或使用: newgrp video"
        ((warnings++))
    else
        log_success "✅ 用户已在video组中"
    fi

    # 6. 网络连接检查（区分不同API服务）
    log_info "🌐 检查多模态API服务连接..."

    # ASR服务端点检查
    log_info "   🎤 ASR语音识别服务:"
    local asr_endpoints=(
        "nls-gateway.cn-shanghai.aliyuncs.com:443:阿里云ASR主服务"
        "nls-meta.cn-shanghai.aliyuncs.com:443:阿里云Token服务"
    )

    for endpoint_info in "${asr_endpoints[@]}"; do
        local endpoint=$(echo "$endpoint_info" | cut -d':' -f1-2)
        local desc=$(echo "$endpoint_info" | cut -d':' -f3-)
        local host=$(echo "$endpoint" | cut -d':' -f1)
        local port=$(echo "$endpoint" | cut -d':' -f2)

        if timeout 5 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
            log_success "✅ $desc ($host:$port)"
        else
            log_error "❌ $desc 不可达 ($host:$port)"
            ((errors++))
        fi
    done

    # TTS服务端点检查
    log_info "   🔊 TTS语音合成服务:"
    local tts_endpoints=(
        "nls-gateway.cn-shanghai.aliyuncs.com:443:阿里云TTS服务"
    )

    for endpoint_info in "${tts_endpoints[@]}"; do
        local endpoint=$(echo "$endpoint_info" | cut -d':' -f1-2)
        local desc=$(echo "$endpoint_info" | cut -d':' -f3-)
        local host=$(echo "$endpoint" | cut -d':' -f1)
        local port=$(echo "$endpoint" | cut -d':' -f2)

        if timeout 5 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
            log_success "✅ $desc ($host:$port)"
        else
            log_error "❌ $desc 不可达 ($host:$port)"
            ((errors++))
        fi
    done

    # LLM服务端点检查
    log_info "   🧠 LLM大语言模型服务:"
    local llm_endpoints=(
        "dashscope.aliyuncs.com:443:通义千问API"
        "dashscope.aliyuncs.com:443:通义千问推理服务"
    )

    for endpoint_info in "${llm_endpoints[@]}"; do
        local endpoint=$(echo "$endpoint_info" | cut -d':' -f1-2)
        local desc=$(echo "$endpoint_info" | cut -d':' -f3-)
        local host=$(echo "$endpoint" | cut -d':' -f1)
        local port=$(echo "$endpoint" | cut -d':' -f2)

        if timeout 5 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
            log_success "✅ $desc ($host:$port)"
        else
            log_warning "⚠️ $desc 不可达 ($host:$port) - LLM功能将受限"
            ((warnings++))
        fi
    done

    # 视觉理解服务端点检查
    log_info "   👁️ 视觉理解服务:"
    local vision_endpoints=(
        "dashscope.aliyuncs.com:443:Qwen-VL多模态API"
    )

    for endpoint_info in "${vision_endpoints[@]}"; do
        local endpoint=$(echo "$endpoint_info" | cut -d':' -f1-2)
        local desc=$(echo "$endpoint_info" | cut -d':' -f3-)
        local host=$(echo "$endpoint" | cut -d':' -f1)
        local port=$(echo "$endpoint" | cut -d':' -f2)

        if timeout 5 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
            log_success "✅ $desc ($host:$port)"
        else
            log_warning "⚠️ $desc 不可达 ($host:$port) - 视觉功能将受限"
            ((warnings++))
        fi
    done

    # 7. 环境变量检查
    log_info "🔑 检查多模态服务环境变量..."
    local env_vars=(
        "ALIBABA_CLOUD_ACCESS_KEY_ID"
        "ALIBABA_CLOUD_ACCESS_KEY_SECRET"
        "ALIYUN_NLS_APPKEY"
        "QWEN_API_KEY"
        "PYTHONPATH"
    )

    for var in "${env_vars[@]}"; do
        if [ -n "${!var}" ]; then
            local value="${!var}"
            if [ ${#value} -gt 20 ]; then
                value="${value:0:20}..."
            fi
            log_success "✅ $var=$value"
        else
            log_warning "⚠️ 未设置: $var"
            ((warnings++))
        fi
    done

    # 8. 音频设备检查
    log_info "🎤 检查音频设备..."

    # 检查录音设备
    if arecord -l &> /dev/null; then
        local input_devices=$(arecord -l | grep -c "card [0-9]*:")
        log_success "✅ 录音设备: 找到 $input_devices 个设备"

        # 显示设备详情
        if [ "$input_devices" -gt 0 ]; then
            echo "   录音设备列表:"
            arecord -l | grep "card [0-9]*:" | sed 's/^/     /'
        fi
    else
        log_error "❌ 无录音设备或arecord不可用"
        ((errors++))
    fi

    # 检查播放设备
    if aplay -l &> /dev/null; then
        local output_devices=$(aplay -l | grep -c "card [0-9]*:")
        log_success "✅ 播放设备: 找到 $output_devices 个设备"

        # 显示设备详情
        if [ "$output_devices" -gt 0 ]; then
            echo "   播放设备列表:"
            aplay -l | grep "card [0-9]*:" | sed 's/^/     /'
        fi
    else
        log_error "❌ 无播放设备或aplay不可用"
        ((errors++))
    fi

    # 9. 系统资源检查
    log_info "💻 检查系统资源..."

    # 内存检查
    local total_memory=$(free -m | awk 'NR==2{print $2}')
    local available_memory=$(free -m | awk 'NR==2{print $7}')
    local memory_usage=$(( (total_memory - available_memory) * 100 / total_memory ))

    log_info "   内存: ${available_memory}MB可用 / ${total_memory}MB总计 (${memory_usage}%)"
    if [ "$available_memory" -lt 1000 ]; then
        log_warning "⚠️ 可用内存不足1GB，可能影响性能"
        ((warnings++))
    else
        log_success "✅ 内存充足"
    fi

    # CPU检查
    local cpu_cores=$(nproc)
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | tr -d ',')
    log_info "   CPU: $cpu_cores 核心，负载: $cpu_load"

    # 磁盘空间检查
    local disk_available=$(df -m "$PROJECT_ROOT" | awk 'NR==2{print $4}')
    if [ "$disk_available" -lt 1000 ]; then
        log_warning "⚠️ 磁盘空间不足: ${disk_available}MB"
        ((warnings++))
    else
        log_success "✅ 磁盘空间充足: ${disk_available}MB"
    fi

    # 10. 权限检查
    log_info "🔐 检查权限..."

    # 检查项目目录写权限
    if [ -w "$PROJECT_ROOT" ]; then
        log_success "✅ 项目目录写权限正常"
    else
        log_error "❌ 项目目录无写权限"
        ((errors++))
    fi

    # 检查日志目录权限
    local log_dir=$(dirname "$LOG_FILE")
    if [ -w "$log_dir" ]; then
        log_success "✅ 日志目录写权限正常"
    else
        log_error "❌ 日志目录无写权限: $log_dir"
        ((errors++))
    fi

    # 11. 端口检查
    log_info "🔌 检查多模态服务端口占用..."
    local ports=("8000" "8080" "9000" "3000" "5000" "8081")

    for port in "${ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log_warning "⚠️ 端口 $port 被占用"
            ((warnings++))
        else
            log_success "✅ 端口 $port 可用"
        fi
    done

    # 总结检查结果
    echo "=================================="
    log_info "📊 环境检查总结:"
    log_info "   - 错误: $errors 个"
    log_info "   - 警告: $warnings 个"

    if [ $errors -gt 0 ]; then
        log_error "❌ 环境检查失败，存在 $errors 个错误"
        echo ""
        log_info "🛠️ 建议修复步骤:"
        if [ $errors -gt 0 ]; then
            echo "   1. 安装缺失的Python模块: pip3.10 install -r requirements.txt"
            echo "   2. 检查音频设备: sudo apt-get install alsa-utils pulseaudio"
            echo "   3. 设置环境变量: export ALIBABA_CLOUD_ACCESS_KEY_ID='your_key'"
            echo "   4. 确保项目完整: git pull 或重新克隆"
        fi
        echo ""
        log_error "请修复错误后重试，或使用 --force 参数强制启动"
        exit 1
    elif [ $warnings -gt 0 ]; then
        log_warning "⚠️ 环境检查通过，但存在 $warnings 个警告"
        log_info "服务可能可以运行，但建议解决警告问题"
    else
        log_success "🎉 环境检查完全通过！系统准备就绪"
    fi

    echo ""
}

# 检查服务状态
check_status() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            log_success "✅ 服务正在运行 (PID: $pid)"

            # 显示进程详情
            echo -e "${CYAN}进程详情:${NC}"
            ps -p "$pid" -o pid,ppid,cmd,etime,pcpu,pmem --no-headers | while read line; do
                echo -e "   $line"
            done

            return 0
        else
            log_warning "⚠️ PID文件存在但进程不运行，清理中..."
            rm -f "$PID_FILE"
            return 1
        fi
    else
        log_warning "⚠️ 服务未运行"
        return 1
    fi
}

# 启动服务
start_service() {
    local force_start=false
    if [ "$1" = "--force" ]; then
        force_start=true
        log_warning "⚠️ 强制启动模式，跳过部分检查"
    fi

    log_info "🚀 启动XleRobot Epic 1语音助手..."

    # 检查是否已经运行
    if check_status > /dev/null 2>&1; then
        log_warning "⚠️ 服务已在运行中"
        return 0
    fi

    # 环境检查
    if [ "$force_start" = false ]; then
        check_environment
    else
        log_info "⚠️ 跳过环境检查（强制启动模式）"
    fi

    # 切换到项目目录
    cd "$PROJECT_ROOT"

    # 设置环境变量
    export PYTHONPATH="$PROJECT_ROOT/src:$PYTHONPATH"
    export ROS_DOMAIN_ID="42"

    # 从环境文件加载API密钥
    if [[ -f ".env" ]]; then
        source .env
    fi

    # 验证必需的环境变量
    required_vars=("ALIBABA_CLOUD_ACCESS_KEY_ID" "ALIBABA_CLOUD_ACCESS_KEY_SECRET" "ALIYUN_NLS_APPKEY" "QWEN_API_KEY")
    for var in "${required_vars[@]}"; do
        if [[ -z "${!var}" ]]; then
            echo "❌ 错误: 环境变量 $var 未设置"
            echo "请确保在 .env 文件中设置了所有必需的API密钥"
            exit 1
        fi
    done

    log_info "🔧 环境变量已设置"

    # 启动服务
    log_info "🎤 启动ROS2语音助手服务..."

    # 检查ROS2包是否编译
    if [ ! -f "install/setup.bash" ]; then
        log_error "❌ ROS2包未编译，请运行: colcon build --packages-select xlerobot audio_msg"
        return 1
    fi

    # 启动ROS2 Launch系统
    source /opt/ros/humble/setup.bash
    source install/setup.bash

    nohup ros2 launch xlerobot voice_assistant.launch.py \
        qwen_api_key:="${QWEN_API_KEY}" \
        tts_voice:=xiaoyun \
        log_level:=info \
        > "$LOG_FILE" 2>&1 &
    local pid=$!

    # 保存PID
    echo $pid > "$PID_FILE"

    log_success "✅ 服务启动中... (PID: $pid)"

    # 等待服务启动
    sleep 3

    # 检查启动状态
    if ps -p "$pid" > /dev/null 2>&1; then
        log_success "🎉 XleRobot Epic 1语音助手启动成功！"
        log_info "📁 日志文件: $LOG_FILE"
        log_info "🎮 使用 '$0 logs' 查看实时日志"
        log_info "🛑 使用 '$0 stop' 停止服务"
        log_info "🔄 使用 '$0 restart' 重启服务"
    else
        log_error "❌ 服务启动失败，请检查日志"
        tail -n 20 "$LOG_FILE"
        rm -f "$PID_FILE"
        exit 1
    fi
}

# 停止服务
stop_service() {
    log_info "🛑 停止XleRobot Epic 1语音助手..."

    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")

        if ps -p "$pid" > /dev/null 2>&1; then
            # 发送TERM信号
            kill -TERM "$pid"
            log_info "已发送停止信号到进程 $pid"

            # 等待进程优雅退出
            local count=0
            while ps -p "$pid" > /dev/null 2>&1 && [ $count -lt 10 ]; do
                sleep 1
                count=$((count + 1))
            done

            # 如果进程仍在运行，强制终止
            if ps -p "$pid" > /dev/null 2>&1; then
                log_warning "⚠️ 进程未优雅退出，强制终止..."
                kill -KILL "$pid"
                sleep 1
            fi

            # 清理PID文件
            rm -f "$PID_FILE"
            log_success "✅ 服务已停止"
        else
            log_warning "⚠️ 进程不存在，清理PID文件"
            rm -f "$PID_FILE"
        fi
    else
        log_warning "⚠️ PID文件不存在，服务可能未运行"
    fi

    # 清理可能的残留进程
    pkill -f "start_epic1_services.py" 2>/dev/null || true
    pkill -f "asr_bridge_node" 2>/dev/null || true
    pkill -f "llm_service_node" 2>/dev/null || true
    pkill -f "tts_service_node" 2>/dev/null || true
    pkill -f "voice_assistant_coordinator" 2>/dev/null || true
}

# 重启服务
restart_service() {
    log_info "🔄 重启XleRobot Epic 1语音助手..."
    stop_service
    sleep 2
    start_service
}

# 显示日志
show_logs() {
    log_info "📋 XleRobot Epic 1语音助手日志:"
    echo "================================================"

    if [ -f "$LOG_FILE" ]; then
        tail -n 50 "$LOG_FILE"
        echo ""
        echo "================================================"
        log_info "📁 完整日志文件: $LOG_FILE"
        log_info "🔄 实时查看: tail -f '$LOG_FILE'"
    else
        log_warning "⚠️ 日志文件不存在"
    fi
}

# 主函数
main() {
    case "${1:-start}" in
        "start")
            show_banner
            start_service "${2:-}"
            ;;
        "--force")
            show_banner
            start_service "--force"
            ;;
        "status")
            show_banner
            check_status
            ;;
        "stop")
            show_banner
            stop_service
            ;;
        "restart")
            show_banner
            restart_service
            ;;
        "logs")
            show_logs
            ;;
        "check")
            show_banner
            check_environment
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"